#
# TABLE STRUCTURE FOR: album
#

DROP TABLE IF EXISTS `album`;

CREATE TABLE `album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: album_image
#

DROP TABLE IF EXISTS `album_image`;

CREATE TABLE `album_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=utf8;

INSERT INTO `album_image` (`id`, `album_id`, `image`, `thumb`) VALUES (136, 92, '783_92.jpg', 't-783_92.jpg');
INSERT INTO `album_image` (`id`, `album_id`, `image`, `thumb`) VALUES (137, 92, '283_92.jpg', 't-283_92.jpg');
INSERT INTO `album_image` (`id`, `album_id`, `image`, `thumb`) VALUES (138, 92, '757_92.jpg', 't-757_92.jpg');
INSERT INTO `album_image` (`id`, `album_id`, `image`, `thumb`) VALUES (139, 95, '346_95.png', 't-346_95.png');
INSERT INTO `album_image` (`id`, `album_id`, `image`, `thumb`) VALUES (140, 95, '815_95.png', 't-815_95.png');


#
# TABLE STRUCTURE FOR: basic_details
#

DROP TABLE IF EXISTS `basic_details`;

CREATE TABLE `basic_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `dob` date NOT NULL,
  `age` int(11) NOT NULL,
  `months` int(11) NOT NULL,
  `height` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL,
  `marital_status` int(11) NOT NULL,
  `parish_name` varchar(255) NOT NULL,
  `parish_place` varchar(255) NOT NULL,
  `family_status` int(11) NOT NULL,
  `about` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `basic_details` (`id`, `user_id`, `dob`, `age`, `months`, `height`, `weight`, `marital_status`, `parish_name`, `parish_place`, `family_status`, `about`) VALUES (1, 92, '2022-10-01', 0, 0, '6 Ft 11 In / 211 Cms', 42, 1, '123', 'Qwe', 1, 'i have done my Any Masters in Engineering / Computers ( M.Tech. ). i am working in Australia. i come from Middle Class family. Currently living in thodupuzha.');
INSERT INTO `basic_details` (`id`, `user_id`, `dob`, `age`, `months`, `height`, `weight`, `marital_status`, `parish_name`, `parish_place`, `family_status`, `about`) VALUES (2, 95, '2022-10-03', 0, 0, '6 Ft 8 In / 203 Cms', 45, 1, '', '', 1, 'I am creating this profile on behalf of my Relative Jasooly Baliq.he have done his  (  ). he is working in Austria. he come from Middle Class family. Currently living in Varkala.');
INSERT INTO `basic_details` (`id`, `user_id`, `dob`, `age`, `months`, `height`, `weight`, `marital_status`, `parish_name`, `parish_place`, `family_status`, `about`) VALUES (3, 15, '2022-10-03', 0, 0, '6 Ft 11 In / 211 Cms', 58, 1, 'SDFGHH', 'EWRETRHG', 1, 'I am creating this profile on behalf of my  robinrr.he have done his Any Diploma ( Diploma ). he is working in Belize. he come from Middle Class family. Currently living in .');
INSERT INTO `basic_details` (`id`, `user_id`, `dob`, `age`, `months`, `height`, `weight`, `marital_status`, `parish_name`, `parish_place`, `family_status`, `about`) VALUES (4, 96, '1990-02-03', 32, 8, '6 Ft 11 In / 211 Cms', 60, 1, 'jawahar', 'jawahar', 1, 'i have done my Any Bachelors in Arts / Science / Commerce ( B.Sc. ). i am working in India. i come from Middle Class family. Currently living in varkala.');
INSERT INTO `basic_details` (`id`, `user_id`, `dob`, `age`, `months`, `height`, `weight`, `marital_status`, `parish_name`, `parish_place`, `family_status`, `about`) VALUES (5, 97, '1998-10-13', 23, 11, '6 Ft 11 In / 211 Cms', 58, 1, '', 'kollam', 1, 'i have done my Any Bachelors in Engineering / Computers ( B.Tech. ). i am working in India. i come from Middle Class family. Currently living in kollam.');


#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (1, 'movies_music', 'Movies & Music');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (2, 'science_technology', 'Science & Technology');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (3, 'pets_animals', 'Pets & Animals');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (4, 'vehicles_automobiles', 'Vehicles & Automobiles');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (5, 'art_culture', 'Art & Culture');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (6, 'education_knowledge', 'Education & Knowledge');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (7, 'food_restaurant', 'Food & Restaurant');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (8, 'travel_tours', 'Travel & Tours');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (9, 'politics_current_affairs', 'Politics & Current Affairs');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (10, 'games', 'Games');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (11, 'business_economics', 'Business & Economics');
INSERT INTO `categories` (`id`, `slug`, `name`) VALUES (12, 'healthcare', 'Healthcare');


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS `core`;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `header_logo` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `sms_user` varchar(255) NOT NULL,
  `sms_password` varchar(255) NOT NULL,
  `sms_sender_id` varchar(30) NOT NULL,
  `is_smtp` tinyint(1) NOT NULL,
  `smtp_host` varchar(255) NOT NULL,
  `smtp_port` varchar(255) NOT NULL,
  `smtp_username` varchar(255) NOT NULL,
  `smtp_password` varchar(255) NOT NULL,
  `connection_prefix` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `core` (`id`, `site_name`, `email`, `header_logo`, `logo`, `sms_user`, `sms_password`, `sms_sender_id`, `is_smtp`, `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `connection_prefix`) VALUES (1, 'Interface Matrimony', 'info@smartipz.com', 'IFM,M.png', 'IFM.png', 'jasooly007', 'G37LXH4U123', 'SMRTPZ', 0, 'smtp.gmail.com', '587', 'robin.smartipz@gmail.com', 'Asdqwe123@', 'tls');


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `country` varchar(255) DEFAULT NULL,
  `tel_code` varchar(10) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `currency_2` varchar(10) NOT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `country_code_iso_3` varchar(10) NOT NULL,
  `currency_symbol` varchar(5) DEFAULT NULL,
  `active` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8;

INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (1, 'Abkhazia', '840', 'RUB', 'EURO', 'AB', 'ABK', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (2, 'Afghanistan', '93', 'AFN', 'USD', 'AF', 'AFG', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (3, 'Albania', '355', 'ALL', 'EURO', 'AL', 'ALB', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (4, 'Algeria', '213', 'DZD', 'USD', 'DZ', 'DZA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (5, 'Andorra', '376', 'EUR', 'EUR', 'AD', 'AND', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (6, 'Angola', '244', 'AOA', 'USD', 'AO', 'AGO', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (7, 'Antigua and Barbuda', '1 268', 'XCD', 'USD', 'AG', 'ATG', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (8, 'Argentina', '54', 'ARS', 'USD', 'AR', 'ARG', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (9, 'Armenia', '374', 'AMD', 'EURO', 'AM', 'ARM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (10, 'Australia', '61', 'AUD', 'AUD', 'AU', 'AUS', 'A$', 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (11, 'Austria', '43', 'EUR', '', 'AT', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (12, 'Bahamas', '1 242', 'BSD', 'USD', 'BS', 'BHS', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (13, 'Bahrain', '973', 'BHD', 'USD', 'BH', 'BHR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (14, 'Bangladesh', '880', 'BDT', 'USD', 'BD', 'BGD', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (15, 'Barbados', '1 246', 'BBD', 'USD', 'BB', 'BRB', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (16, 'Belarus', '375', 'BYR', 'EURO', 'BY', 'BLR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (17, 'Belgium', '32', 'EUR', 'EUR', 'BE', 'BEL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (18, 'Belize', '501', 'BZD', 'USD', 'BZ', 'BLZ', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (19, 'Benin', '229', 'XOF', 'USD', 'BJ', 'BEN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (20, 'Bhutan', '975', 'BTN', 'USD', 'BT', 'BTN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (21, 'Bolivia', '591', 'BOB', 'USD', 'BO', 'BOL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (22, 'Bosnia and Herzegovina', '387', 'BAM', 'EURO', 'BA', 'BIH', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (23, 'Botswana', '267', 'BWP', 'USD', 'BW', 'BWA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (24, 'Brazil', '55', 'BRL', 'USD', 'BR', 'BRA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (25, 'Brunei Darussalam\r\n', '673', 'BND', 'USD', 'BN', 'BRN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (26, 'Bulgaria', '359', 'EUR', 'EUR', 'BG', 'BGR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (27, 'Burkina Faso', '226', 'XOF', 'USD', 'BF', 'BFA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (28, 'Burma', '291', 'ERN', 'USD', 'ER', 'ERI', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (29, 'Burundi', '257', 'BIF', 'USD', 'BI', 'BDI', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (30, 'Cambodia', '855', 'KHR', 'USD', 'KH', 'KHM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (31, 'Cameroon', '237', 'XAF', 'USD', 'CM', 'CMR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (32, 'Canada', '1', 'CAD', 'CAD', 'CA', 'CAN', 'C$', 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (33, 'Cape Verde', '238', 'CVE', 'USD', 'CV', 'CPV', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (34, 'Central African Republic', '236', 'XAF', 'USD', 'CF', 'CAF', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (35, 'Chad', '235', 'XAF', 'USD', 'TD', 'TCD', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (36, 'Chile', '56', 'CLP', 'USD', 'CL', 'CHL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (37, 'China', '86', 'CNY', 'GBP', 'CN', 'CHN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (38, 'Colombia', '57', 'COP', 'COP', 'CO', 'COL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (39, 'Comoros', '269', 'KNF', 'USD', 'KM', 'COM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (40, 'Democratic Republic of Congo', '243', 'XAF', 'USD', 'CD', 'COD', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (41, 'Cook Islands', '682', 'NZD', 'USD', 'CK', 'COK', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (42, 'Costa Rica', '506', 'CRC', 'USD', 'CR', 'CRI', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (43, 'Croatia', '385', 'HRK', 'EURO', 'HR', 'HRV', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (44, 'Cuba', '53', 'CUP', 'USD', 'CU', 'CUB', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (45, 'Cyprus', '357', 'EUR', 'EUR', 'CY', 'CYP', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (46, 'Czech Republic', '420', 'CZK', 'EURO', 'CZ', 'CZE', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (47, 'Côte d\'Ivoire', '225', 'XOF', 'USD', 'CI', 'CIV', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (48, 'Denmark', '45', 'DKK', 'EUR', 'DK', 'DNK', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (49, 'Djibouti', '253', 'DJF', 'USD', 'DJ', 'DJI', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (50, 'Dominica', '1 767', 'XCD', 'USD', 'DM', 'DMA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (51, 'Dominican Republic', '1 809', 'DOP', 'USD', 'DO', 'DOM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (52, 'East Timor', '670', 'USD', 'USD', 'TL', 'TLS', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (53, 'Ecuador', '593', 'USD', 'USD', 'EC', 'ECU', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (54, 'Egypt', '20', 'EGP', 'USD', 'EG', 'EGY', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (55, 'El Salvador', '503', 'USD', 'USD', 'SV', 'SLV', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (56, 'Equatorial Guinea', '240', 'XAF', 'USD', 'GQ', 'GNQ', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (57, 'Eritrea', '291', 'ERN', 'ERN', 'ER', 'ERI', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (58, 'Estonia', '372', 'EURO', 'EURO', 'EE', 'EST', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (59, 'Ethiopia', '251', 'ETB', 'ETB', 'ET', 'ETH', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (60, 'Fiji', '679', 'FJD', 'FJD', 'FJ', 'FJI', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (61, 'Finland', '358', 'EUR', 'EUR', 'FI', 'FIN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (62, 'France', '33', 'EUR', 'EUR', 'FR', 'FRA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (63, 'Gabon', '241', NULL, '', 'GA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (64, 'Gambia', '220', NULL, '', 'GM', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (65, 'Georgia', '995', NULL, '', 'GE', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (66, 'Germany', '49', 'EUR', 'EUR', 'DE', 'DEU', NULL, 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (67, 'Ghana', '233', NULL, '', 'GH', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (68, 'Greece', '30', 'EUR', 'EUR', 'GR', 'GRC', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (69, 'Grenada', '1 473', NULL, '', 'GD', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (70, 'Guatemala', '502', NULL, '', 'GT', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (71, 'Guinea', '224', NULL, '', 'GN', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (72, 'Guinea-Bissau', '245', NULL, '', 'GW', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (73, 'Guyana', '592', NULL, '', 'GY', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (74, 'Haiti', '509', NULL, '', 'HT', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (75, 'Honduras', '504', NULL, '', 'HN', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (76, 'Hungary', '36', 'HUF', 'EUR', 'HU', 'HUN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (77, 'Iceland', '354', NULL, '', 'IS', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (78, 'India', '91', 'INR', 'INR', 'IN', 'IND', 'Rs', 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (79, 'Indonesia', '62', NULL, '', 'ID', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (80, 'Iran', '98', NULL, '', 'IR', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (81, 'Iraq', '964', NULL, '', 'IQ', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (82, 'Ireland', '353', 'EUR', 'EUR', 'IE', 'IRL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (83, 'Israel', '972', 'ISL', 'EUR', 'IL', 'ISR', NULL, 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (84, 'Italy', '39', 'EUR', 'EUR', 'IT', 'ITA', NULL, 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (85, 'Ivory Coast', '225', NULL, '', 'CI', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (86, 'Jamaica', '1 876', NULL, '', 'JM', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (87, 'Japan', '81', 'JPY', 'USD', 'JP', 'JPN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (88, 'Jordan', '962', NULL, '', 'JO', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (89, 'Kazakhstan', '7', NULL, '', 'KZ', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (90, 'Kenya', '254', NULL, '', 'KE', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (91, 'Kiribati', '686', NULL, '', 'KI', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (92, 'Korea, North', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (93, 'Korea, South', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (94, 'Kosovo', '381', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (95, 'Kuwait', '965', NULL, '', 'KW', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (96, 'Kyrgyzstan', '996', NULL, '', 'KG', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (97, 'Laos', '856', NULL, '', 'LA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (98, 'Latvia', '371', NULL, '', 'LV', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (99, 'Lebanon', '961', NULL, '', 'LB', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (100, 'Lesotho', '266', NULL, '', 'LS', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (101, 'Liberia', '231', NULL, '', 'LR', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (102, 'Libya', '218', NULL, '', 'LY', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (103, 'Liechtenstein', '423', 'EUR', 'EUR', 'LI', 'LIE', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (104, 'Lithuania', '370', NULL, '', 'LT', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (105, 'Luxembourg', '352', 'EUR', 'EUR', 'LU', 'LUX', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (106, 'Macedonia', '389', NULL, '', 'MK', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (107, 'Madagascar', '261', NULL, '', 'MG', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (108, 'Malawi', '265', NULL, '', 'MW', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (109, 'Malaysia', '60', 'MYR', 'USD', 'MY', 'MYS', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (110, 'Maldives', '960', NULL, '', 'MV', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (111, 'Mali', '223', NULL, '', 'ML', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (112, 'Malta', '356', 'EUR', 'EUR', 'MT', 'MLT', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (113, 'Marshall Islands', '692', NULL, '', 'MH', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (114, 'Mauritania', '222', NULL, '', 'MR', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (115, 'Mauritius', '230', NULL, '', 'MU', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (116, 'Mexico', '52', 'MXN', 'USD', 'MX', 'MEX', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (117, 'Micronesia', '691', NULL, '', 'FM', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (118, 'Moldova', '373', NULL, '', 'MD', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (119, 'Monaco', '377', 'EUR', 'EUR', 'MC', 'MCO', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (120, 'Mongolia', '976', NULL, '', 'MN', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (121, 'Montenegro', '382', NULL, '', 'ME', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (122, 'Morocco', '212', NULL, '', 'MA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (123, 'Mozambique', '258', 'MZN', 'USD', 'MZ', 'MOZ', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (124, 'Myanmar / Burma', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (125, 'Nagorno-Karabakh', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (126, 'Namibia', '264', NULL, '', 'NA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (127, 'Nauru', '674', NULL, '', 'NR', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (128, 'Nepal', '977', NULL, '', 'NP', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (129, 'Netherlands', '31', 'EUR', 'EUR', 'NL', 'NLD', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (130, 'New Zealand', '64', 'NZD', 'USD', 'NZ', 'NZL', NULL, 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (131, 'Nicaragua', '505', NULL, '', 'NI', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (132, 'Niger', '227', NULL, '', 'NE', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (133, 'Nigeria', '234', NULL, '', 'NG', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (134, 'Niue', '683', NULL, '', 'NU', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (135, 'Northern Cyprus', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (136, 'Norway', '47', 'NOK', 'EUR', 'NO', 'NOR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (137, 'Oman', '968', NULL, '', 'OM', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (138, 'Pakistan', '92', NULL, '', 'PK', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (139, 'Palau', '680', NULL, '', 'PW', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (140, 'Palestine', '970', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (141, 'Panama', '507', NULL, '', 'PA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (142, 'Papua New Guinea', '675', NULL, '', 'PG', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (143, 'Paraguay', '595', NULL, '', 'PY', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (144, 'Peru', '51', 'PEN', 'COP', 'PE', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (145, 'Philippines', '63', 'PHP', 'USD', 'PH', 'PHL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (146, 'Poland', '48', 'PLN', 'EUR', 'PL', 'POL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (147, 'Portugal', '351', 'EUR', 'EUR', 'PT', 'PRT', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (148, 'Qatar', '974', NULL, '', 'QA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (149, 'Romania', '40', NULL, '', 'RO', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (150, 'Russia', '7', 'RUB', 'EUR', 'RU', 'RUS', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (151, 'Rwanda', '250', NULL, '', 'RW', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (152, 'Sahrawi Arab Democratic Republic', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (153, 'Saint Kitts and Nevis', '1 869', NULL, '', 'KN', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (154, 'Saint Lucia', '1 758', NULL, '', 'LC', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (155, 'Saint Vincent and the Grenadines', '1 784', NULL, '', 'VC', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (156, 'Samoa', '685', NULL, '', 'WS', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (157, 'San Marino', '378', 'EUR', 'EUR', 'SM', 'SMR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (158, 'Saudi Arabia', '966', NULL, '', 'SA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (159, 'Senegal', '221', NULL, '', 'SN', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (160, 'Serbia', '381', NULL, '', 'RS', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (161, 'Seychelles', '248', NULL, '', 'SC', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (162, 'Sierra Leone', '232', NULL, '', 'SL', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (163, 'Singapore', '65', 'SGD', 'USD', 'SG', 'SGP', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (164, 'Slovakia', '421', 'EUR', 'EUR', 'SK', 'SVK', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (165, 'Slovenia', '386', 'EUR', 'EUR', 'SI', 'SVN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (166, 'Solomon Islands', '677', NULL, '', 'SB', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (167, 'Somalia', '252', NULL, '', 'SO', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (168, 'Somaliland', '252', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (169, 'South Africa', '27', 'ZAR', 'USD', 'ZA', 'ZAF', NULL, 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (170, 'South Ossetia', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (171, 'Spain', '34', 'EUR', 'EUR', 'ES', 'ESP', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (172, 'Sri Lanka', '94', NULL, '', 'LK', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (173, 'Sudan', '249', NULL, '', 'SD', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (174, 'Suriname', '597', NULL, '', 'SR', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (175, 'Swaziland', '268', NULL, '', 'SZ', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (176, 'Sweden', '46', 'SEK', 'EUR', 'SE', 'SWE', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (177, 'Switzerland', '41', 'CHF', 'EUR', 'CH', 'CHE', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (178, 'Syria', '963', NULL, '', 'SY', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (179, 'São Tomé and Príncipe', '239', NULL, '', 'ST', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (180, 'Taiwan', '886', 'TWD', 'USD', 'TW', 'TWN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (181, 'Tajikistan', '992', NULL, '', 'TJ', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (182, 'Tanzania', '255', NULL, '', 'TZ', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (183, 'Thailand', '66', 'THB', 'USD', 'TH', 'THA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (184, 'Timor-Leste / East Timor', '0', NULL, '', NULL, '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (185, 'Togo', '228', NULL, '', 'TG', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (186, 'Tonga', '676', NULL, '', 'TO', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (187, 'Trinidad and Tobago', '1 868', NULL, '', 'TT', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (188, 'Tunisia', '216', NULL, '', 'TN', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (189, 'Turkey', '90', 'TRY', 'EUR', 'TR', 'TUR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (190, 'Turkmenistan', '993', NULL, '', 'TM', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (191, 'Tuvalu', '688', NULL, '', 'TV', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (192, 'Uganda', '256', NULL, '', 'UG', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (193, 'Ukraine', '380', NULL, '', 'UA', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (194, 'United Arab Emirates', '971', NULL, '', 'AE', '', NULL, 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (195, 'United Kingdom', '44', 'GBP', 'COP', 'GB', 'GBR', '£', 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (196, 'United States', '1', 'USD', 'USD', 'US', 'USA', '$', 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (197, 'Uruguay', '598', NULL, '', 'UY', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (198, 'Uzbekistan', '998', NULL, '', 'UZ', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (199, 'Vanuatu', '678', NULL, '', 'VU', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (200, 'Vatican City', '39', 'EUR', 'EUR', 'VAT', 'VAT', NULL, 1);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (201, 'Venezuela', '58', NULL, '', 'VE', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (202, 'Vietnam', '84', NULL, '', 'VN', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (203, 'Yemen', '967', NULL, '', 'YE', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (204, 'Zambia', '260', NULL, '', 'ZM', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (205, 'Zimbabwe', '263', NULL, '', 'ZW', '', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (206, 'Gibraltar', '350', 'GIP', 'GBP', 'GI', 'GIB', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (207, 'Aland Islands', '35818', NULL, '', 'AX', 'ALA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (208, 'American Samoa', '1-684', NULL, '', 'AS', 'ASM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (209, 'Anguilla\r\n', '1-264', NULL, '', 'AI', 'AIA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (210, 'Antarctica\r\n', '672', NULL, '', 'AQ', 'ATA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (211, 'Aruba\r\n', '297', NULL, '', 'AW', 'ABW', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (212, 'Bermuda', '1-441', NULL, '', 'BM', 'BMU', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (213, 'Bouvet Island', NULL, NULL, '', 'BV', 'BVT', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (214, 'British Indian Ocean Territory', '246', NULL, '', 'IO', 'IOT', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (215, 'Guernsey', '44-1481', NULL, '', 'GG', 'GGY', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (216, 'Cayman Islands', '1-345', NULL, '', 'KY', 'CYM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (217, 'Christmas Island', '61', NULL, '', 'CX', 'CXR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (218, 'Cocos (Keeling) Islands', '61', NULL, '', 'CC', 'CCK', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (219, 'Falkland Islands (Malvinas) ', '500', NULL, '', 'FK', 'FLK', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (220, 'Faroe Islands', '298', NULL, '', 'FO', 'FRO', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (221, 'French Guiana', NULL, NULL, '', 'GF', 'GUF', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (222, 'French Polynesia', '689', NULL, '', 'PF', 'PYF', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (223, 'French Southern Territories\r\n', NULL, NULL, '', 'TF', 'ATF', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (224, 'Greenland', '299', NULL, '', 'GL', 'GRL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (225, 'Guadeloupe', NULL, NULL, '', 'GP', 'GLP', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (226, 'Guam', '1-671', NULL, '', 'GU', 'GUM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (227, 'Heard Island and Mcdonald Islands', NULL, NULL, '', 'HM', 'HMD', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (228, 'Holy See (Vatican City State)', NULL, NULL, '', 'VA', 'VAT', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (229, 'Hong Kong', '852', NULL, '', 'HK', 'HKG', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (230, 'Isle of Man', '44-1624', NULL, '', 'IM', 'IMN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (231, 'Jersey', '44-1534', NULL, '', 'JE', 'JEY', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (232, 'Macao', NULL, NULL, '', 'MO', 'MAC', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (233, 'Martinique', NULL, NULL, '', 'MQ', 'MTQ', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (234, 'Mayotte', '262', NULL, '', 'YT', 'MYT', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (235, 'Montserrat', '1-664', NULL, '', 'MS', 'MSR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (236, 'Netherlands Antilles', '599', NULL, '', 'AN', 'ANT', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (237, 'New Caledonia', '687', NULL, '', 'NC', 'NCL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (238, 'Norfolk Island', NULL, NULL, '', 'NF', 'NFK', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (239, 'Northern Mariana Islands', '1-670', NULL, '', 'MP', 'MNP', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (240, 'Pitcairn', '64', NULL, '', 'PN', 'PCN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (241, 'Puerto Rico', '1-787', NULL, '', 'PR', 'PRI', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (242, 'Reunion', '262', NULL, '', 'RE', 'REU', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (243, 'Saint Helena', '290', NULL, '', 'SH', 'SHN', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (244, 'Saint Pierre and Miquelon', '508', NULL, '', 'PM', 'SPM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (245, 'South Georgia and the South Sandwich Islands', NULL, NULL, '', 'GS', 'SGS', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (246, 'Svalbard and Jan Mayen', '47', NULL, '', 'SJ', 'SJM', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (247, 'Tokelau', '690', NULL, '', 'TK', 'TKL', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (248, 'Turks and Caicos Islands', '1-649', NULL, '', 'TC', 'TCA', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (249, 'Virgin Islands, British', '1-284', NULL, '', 'VG', 'VGB', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (250, 'Virgin Islands, U.S.', '1-340', NULL, '', 'VI', 'VIR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (251, 'Wallis and Futuna', '681', NULL, '', 'WF', 'WLF', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (252, 'Western Sahara', '212', NULL, '', 'EH', 'ESH', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (253, 'Korea, Republic of', NULL, NULL, '', 'KR', 'KOR', NULL, 0);
INSERT INTO `countries` (`id`, `country`, `tel_code`, `currency`, `currency_2`, `country_code`, `country_code_iso_3`, `currency_symbol`, `active`) VALUES (254, 'Azerbaijan\r\n', NULL, NULL, '', 'AZ', '', NULL, 0);


#
# TABLE STRUCTURE FOR: district
#

DROP TABLE IF EXISTS `district`;

CREATE TABLE `district` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (1, 1, 'Idukki');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (2, 1, 'Alappuzha');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (3, 1, 'Kottayam');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (5, 1, 'Ernakulam');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (6, 1, 'Kannur');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (7, 1, 'Kasaragod');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (8, 1, 'Kollam');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (9, 1, 'Kozhikode');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (10, 1, 'Malappuram');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (11, 1, 'Palakkad');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (12, 1, 'Pathanamthitta');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (13, 1, 'Thiruvananthapuram');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (14, 1, 'Thrissur');
INSERT INTO `district` (`id`, `state_id`, `name`) VALUES (15, 1, 'Wayanad');


#
# TABLE STRUCTURE FOR: edu_category
#

DROP TABLE IF EXISTS `edu_category`;

CREATE TABLE `edu_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `edu_category` (`id`, `name`) VALUES (3, 'Ph.D.');
INSERT INTO `edu_category` (`id`, `name`) VALUES (4, 'Service - IAS / IPS / IRS / IES / IFS');
INSERT INTO `edu_category` (`id`, `name`) VALUES (5, 'Any Financial Qualification - ICWAI / CA / CS/ CFA');
INSERT INTO `edu_category` (`id`, `name`) VALUES (6, 'Any Masters in Arts / Science / Commerce');
INSERT INTO `edu_category` (`id`, `name`) VALUES (7, 'Any Masters in Engineering / Computers');
INSERT INTO `edu_category` (`id`, `name`) VALUES (8, 'Any Masters in Legal');
INSERT INTO `edu_category` (`id`, `name`) VALUES (9, 'Any Masters in Management');
INSERT INTO `edu_category` (`id`, `name`) VALUES (10, 'Any Masters in Medicine - General / Dental / Surgeon');
INSERT INTO `edu_category` (`id`, `name`) VALUES (11, 'Any Bachelors in Arts / Science / Commerce');
INSERT INTO `edu_category` (`id`, `name`) VALUES (12, 'Any Bachelors in Engineering / Computers');
INSERT INTO `edu_category` (`id`, `name`) VALUES (13, 'Any Bachelors in Legal');
INSERT INTO `edu_category` (`id`, `name`) VALUES (14, 'Any Bachelors in Management');
INSERT INTO `edu_category` (`id`, `name`) VALUES (15, 'Any Bachelors in Medicine in General / Dental / Surgeon');
INSERT INTO `edu_category` (`id`, `name`) VALUES (16, 'Any Diploma');
INSERT INTO `edu_category` (`id`, `name`) VALUES (17, 'Higher Secondary / Secondary');


#
# TABLE STRUCTURE FOR: edu_category_list
#

DROP TABLE IF EXISTS `edu_category_list`;

CREATE TABLE `edu_category_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (6, 3, 'Ph.D.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (7, 4, 'IAS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (8, 4, 'IPS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (9, 4, 'IRS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (10, 4, 'IES');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (11, 4, 'IFS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (12, 4, 'Other Degree in Service');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (13, 5, 'CA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (14, 5, 'CS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (15, 5, 'ICWA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (16, 5, 'CFA (Chartered Financial Analyst)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (17, 5, 'Other Degree in Finance');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (18, 6, 'M.Phil.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (19, 6, 'MCom');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (20, 6, 'M.Sc.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (21, 6, 'M.A.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (22, 6, 'M.Ed.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (23, 6, 'MLIS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (24, 6, 'MSW');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (25, 6, 'Other Master Degree in Arts / Science / Commerce');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (26, 6, 'MFA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (27, 7, 'M.S.(Engg.)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (28, 7, 'M.Arch.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (29, 7, 'MCA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (30, 7, 'PGDCA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (31, 7, 'ME');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (32, 7, 'M.Tech.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (33, 7, 'M.Sc. IT / Computer Science');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (34, 7, 'Other Masters Degree in Engineering / Computers');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (35, 8, 'M.L.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (36, 8, 'LL.M.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (37, 8, 'Other Master Degree in  Legal');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (38, 9, 'MHM  (Hotel Management)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (39, 9, 'MBA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (40, 9, 'PGDM');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (41, 9, 'MHRM (Human Resource Management)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (42, 9, 'MFM (Financial Management)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (43, 9, 'Other Master Degree in Management');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (44, 10, 'MD / MS (Medical)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (45, 10, 'MDS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (46, 10, 'MVSc');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (47, 10, 'MPT');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (48, 10, 'M.Pharm');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (49, 10, 'Other Master Degree in Medicine');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (50, 11, 'B.Phil.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (51, 11, 'B.Com.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (52, 11, 'B.Sc.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (53, 11, 'B.A');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (54, 11, 'B.Ed.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (55, 11, 'Aviation Degree');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (56, 11, 'BFA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (57, 11, 'BLIS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (58, 11, 'B.S.W');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (59, 11, 'B.M.M.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (60, 11, 'BFT');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (61, 11, 'Other Bachelor Degree in Arts / Science / Commerce');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (62, 12, 'BCA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (63, 12, 'Aeronautical Engineering');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (64, 12, 'B.Arch');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (65, 12, 'B.Plan');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (66, 12, 'BE');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (67, 12, 'B.Tech.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (68, 12, 'Other Bachelor Degree in Engineering / Computers');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (69, 12, 'B.Sc IT/ Computer Science');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (70, 13, 'BGL');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (71, 13, 'B.L.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (72, 13, 'LL.B.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (73, 13, 'Other Bachelor Degree in Legal');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (74, 14, 'BHM (Hotel Management)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (75, 14, 'BBA');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (76, 14, 'BFM (Financial Management)');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (77, 14, 'Other Bachelor Degree in Management');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (78, 15, 'MBBS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (79, 15, 'BDS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (80, 15, 'BVSc');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (81, 15, 'BPT');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (82, 15, 'BHMS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (83, 15, 'B.A.M.S.');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (84, 15, 'BPharm');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (85, 15, 'BSMS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (86, 15, 'BUMS');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (87, 15, 'Other Bachelor Degree in Medicine');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (88, 15, 'B.Sc. Nursing');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (89, 16, 'Trade School');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (90, 16, 'Diploma');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (91, 16, 'Polytechnic');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (92, 16, 'Others in Diploma');
INSERT INTO `edu_category_list` (`id`, `category_id`, `name`) VALUES (93, 17, 'Higher Secondary School / High School');


#
# TABLE STRUCTURE FOR: emails
#

DROP TABLE IF EXISTS `emails`;

CREATE TABLE `emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `variables` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `emails` (`id`, `slug`, `subject`, `body`, `variables`) VALUES (1, 'welcome', 'Welcome To Dating', '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:550px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<div style=\"border: solid 1px #d9d9d9;\">\r\n						<div style=\"text-align: center;\">&nbsp;</div>\r\n\r\n						<div style=\"text-align: center;\"><img alt=\"\" src=\"\" style=\"width: 296px; height: 41px;\" /></div>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"content\" style=\"color:#444; font-family:arial,sans-serif; font-size:12px; line-height:1.6; margin-left:30px; margin-right:30px; margin-top:15px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding: 15px 0;\">Welcome and Congratulations,<br />\r\n									<br />\r\n									<br />\r\n									<br />\r\n									Once again, congratulations and we look forward to working for you.<br />\r\n									<br />\r\n									Administrator,<br />\r\n									[*site_name*]</div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"footer\" style=\"font-family:arial,sans-serif; font-size:12px; line-height:1.5; margin-left:30px; margin-right:30px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding-top: 15px; padding-bottom: 1px;\">&nbsp;</div>\r\n\r\n									<div>For any requests, please contact <a href=\"mailto:[*site_email*]\">[*site_email*]</a></div>\r\n									</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"2\">.</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</div>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 'name,email,login-url,site_name,site_email');
INSERT INTO `emails` (`id`, `slug`, `subject`, `body`, `variables`) VALUES (2, 'forgot-password', '[Dating] Password Reset', '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:550px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<div style=\"border: solid 1px #d9d9d9;\">\r\n						<div style=\"text-align: center;\"><img alt=\"\" src=\"\" style=\"width: 296px; height: 41px;\" /></div>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"content\" style=\"color:#444; font-family:arial,sans-serif; font-size:12px; line-height:1.6; margin-left:30px; margin-right:30px; margin-top:15px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding: 15px 0;\">Hi [*name*],<br />\r\n									We received a request to reset your password. If you did not make this request, simply ignore this email. If you did make this request, please click the link below to reset your password:<br />\r\n									<br />\r\n									<strong>[*reset-url*]</strong><br />\r\n									<br />\r\n									If the link above does not work, try copying and pasting it into your browser.<br />\r\n									<br />\r\n									Administrator,<br />\r\n									[*site_name*]</div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"footer\" style=\"font-family:arial,sans-serif; font-size:12px; line-height:1.5; margin-left:30px; margin-right:30px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding-top: 15px; padding-bottom: 1px;\">&nbsp;</div>\r\n\r\n									<div>For any requests, please contact <a href=\"mailto:[*site_email*]\">[*site_email*]</a></div>\r\n									</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"2\">.</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</div>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 'name,reset-url,site_name,site_email');
INSERT INTO `emails` (`id`, `slug`, `subject`, `body`, `variables`) VALUES (3, 'password-changed', 'Password Change Confirmation', '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:550px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<div style=\"border: solid 1px #d9d9d9;\">\r\n						<div style=\"text-align: center;\"><img alt=\"\" src=\"\" style=\"width: 296px; height: 41px;\" /></div>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"content\" style=\"color:#444; font-family:arial,sans-serif; font-size:12px; line-height:1.6; margin-left:30px; margin-right:30px; margin-top:15px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding: 15px 0;\">Hi [*name*],<br />\r\n									<br />\r\n									You have successfully changed your password.<br />\r\n									<br />\r\n									<br />\r\n									Administrator,<br />\r\n									[*site_name*]</div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"footer\" style=\"font-family:arial,sans-serif; font-size:12px; line-height:1.5; margin-left:30px; margin-right:30px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding-top: 15px; padding-bottom: 1px;\">&nbsp;</div>\r\n\r\n									<div>For any requests, please contact <a href=\"mailto:[*site_email*]\">[*site_email*]</a></div>\r\n									</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"2\">.</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</div>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 'name,site_name,site_email');
INSERT INTO `emails` (`id`, `slug`, `subject`, `body`, `variables`) VALUES (10, 'invite-user', 'You\'ve registered to knanaya partner', '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:550px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<div style=\"border: solid 1px #d9d9d9;\">\r\n						<div style=\"text-align: center;\"><img alt=\"\" src=\"\" style=\"width: 296px; height: 41px;\" /></div>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"content\" style=\"color:#444; font-family:arial,sans-serif; font-size:12px; line-height:1.6; margin-left:30px; margin-right:30px; margin-top:15px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding: 15px 0;\">Hi [*name*],<br />\r\n									<br />\r\n									You have registered to [*site_name*], please click the below link to get activated<br />\r\n									<br />\r\n									<strong>[*invite-url*]</strong><br />\r\n									<br />\r\n									If the link above does not work, try copying and pasting it into your browser.<br />\r\n									<br />\r\n									Administrator,<br />\r\n									[*site_name*]</div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"footer\" style=\"font-family:arial,sans-serif; font-size:12px; line-height:1.5; margin-left:30px; margin-right:30px; width:490px\">\r\n							<tbody>\r\n								<tr>\r\n									<td colspan=\"2\">\r\n									<div style=\"padding-top: 15px; padding-bottom: 1px;\">&nbsp;</div>\r\n\r\n									<div>For any requests, please contact <a href=\"mailto:[*site_email*]\">[*site_email*]</a></div>\r\n									</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"2\">.</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</div>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 'name,invite-url,site_name,site_email');


#
# TABLE STRUCTURE FOR: family_details
#

DROP TABLE IF EXISTS `family_details`;

CREATE TABLE `family_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `no_brother_unmarried` int(11) NOT NULL,
  `no_brother_married` int(11) NOT NULL,
  `no_sister_unmarried` int(11) NOT NULL,
  `no_sister_married` int(11) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `family_details` (`id`, `user_id`, `no_brother_unmarried`, `no_brother_married`, `no_sister_unmarried`, `no_sister_married`, `description`) VALUES (1, 92, 0, 6, 0, 0, '');
INSERT INTO `family_details` (`id`, `user_id`, `no_brother_unmarried`, `no_brother_married`, `no_sister_unmarried`, `no_sister_married`, `description`) VALUES (2, 95, 2, 1, 1, 0, '');
INSERT INTO `family_details` (`id`, `user_id`, `no_brother_unmarried`, `no_brother_married`, `no_sister_unmarried`, `no_sister_married`, `description`) VALUES (3, 15, 0, 0, 0, 0, '');
INSERT INTO `family_details` (`id`, `user_id`, `no_brother_unmarried`, `no_brother_married`, `no_sister_unmarried`, `no_sister_married`, `description`) VALUES (4, 96, 0, 1, 0, 2, '');
INSERT INTO `family_details` (`id`, `user_id`, `no_brother_unmarried`, `no_brother_married`, `no_sister_unmarried`, `no_sister_married`, `description`) VALUES (5, 97, 0, 0, 0, 1, '');


#
# TABLE STRUCTURE FOR: friends
#

DROP TABLE IF EXISTS `friends`;

CREATE TABLE `friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_one` int(11) NOT NULL,
  `person_two` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `seen` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `friends` (`id`, `person_one`, `person_two`, `status`, `seen`, `created_at`) VALUES (1, 95, 96, 1, 1, '2022-10-03 05:57:34');
INSERT INTO `friends` (`id`, `person_one`, `person_two`, `status`, `seen`, `created_at`) VALUES (2, 92, 96, 0, 0, '2022-10-03 06:47:20');
INSERT INTO `friends` (`id`, `person_one`, `person_two`, `status`, `seen`, `created_at`) VALUES (3, 95, 97, 1, 1, '2022-10-03 07:08:43');
INSERT INTO `friends` (`id`, `person_one`, `person_two`, `status`, `seen`, `created_at`) VALUES (4, 92, 97, 0, 0, '2022-10-04 04:54:17');


#
# TABLE STRUCTURE FOR: friends_list
#

DROP TABLE IF EXISTS `friends_list`;

CREATE TABLE `friends_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `deactive` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `friends_list` (`id`, `user_id`, `friend_id`, `status`, `deactive`) VALUES (1, 95, 96, 1, 0);
INSERT INTO `friends_list` (`id`, `user_id`, `friend_id`, `status`, `deactive`) VALUES (2, 96, 95, 1, 0);
INSERT INTO `friends_list` (`id`, `user_id`, `friend_id`, `status`, `deactive`) VALUES (3, 95, 97, 1, 0);
INSERT INTO `friends_list` (`id`, `user_id`, `friend_id`, `status`, `deactive`) VALUES (4, 97, 95, 1, 0);


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `groups` (`id`, `title`) VALUES (1, 'Administrator');
INSERT INTO `groups` (`id`, `title`) VALUES (2, 'Host');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_from` int(11) NOT NULL,
  `friend_id_to` int(11) NOT NULL,
  `message` text NOT NULL,
  `seen` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: occ_category
#

DROP TABLE IF EXISTS `occ_category`;

CREATE TABLE `occ_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `occ_category` (`id`, `name`) VALUES (5, 'ADMINISTRATION');
INSERT INTO `occ_category` (`id`, `name`) VALUES (6, 'AGRICULTURE');
INSERT INTO `occ_category` (`id`, `name`) VALUES (7, 'AIRLINE');
INSERT INTO `occ_category` (`id`, `name`) VALUES (8, 'ARCHITECTURE & DESIGN');
INSERT INTO `occ_category` (`id`, `name`) VALUES (9, 'BANKING & FINANCE');
INSERT INTO `occ_category` (`id`, `name`) VALUES (10, 'BEAUTY & FASHION');
INSERT INTO `occ_category` (`id`, `name`) VALUES (11, 'BPO & CUSTOMER SERVICE');
INSERT INTO `occ_category` (`id`, `name`) VALUES (12, 'CIVIL SERVICES');
INSERT INTO `occ_category` (`id`, `name`) VALUES (13, 'CORPORATE PROFESSIONALS');
INSERT INTO `occ_category` (`id`, `name`) VALUES (14, 'DEFENCE');
INSERT INTO `occ_category` (`id`, `name`) VALUES (15, 'EDUCATION & TRAINING');
INSERT INTO `occ_category` (`id`, `name`) VALUES (16, 'ENGINEERING');
INSERT INTO `occ_category` (`id`, `name`) VALUES (17, 'HOSPITALITY');
INSERT INTO `occ_category` (`id`, `name`) VALUES (18, 'IT & SOFTWARE');
INSERT INTO `occ_category` (`id`, `name`) VALUES (19, 'LEGAL');
INSERT INTO `occ_category` (`id`, `name`) VALUES (20, 'LAW ENFORCEMENT');
INSERT INTO `occ_category` (`id`, `name`) VALUES (21, 'MEDICAL & HEALTHCARE');
INSERT INTO `occ_category` (`id`, `name`) VALUES (22, 'MEDIA & ENTERTAINMENT');
INSERT INTO `occ_category` (`id`, `name`) VALUES (23, 'MERCHANT NAVY');
INSERT INTO `occ_category` (`id`, `name`) VALUES (24, 'SCIENTIST');
INSERT INTO `occ_category` (`id`, `name`) VALUES (25, 'TOP MANAGEMENT');
INSERT INTO `occ_category` (`id`, `name`) VALUES (26, 'OTHERS');


#
# TABLE STRUCTURE FOR: occ_category_list
#

DROP TABLE IF EXISTS `occ_category_list`;

CREATE TABLE `occ_category_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;

INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (6, 5, 'Manager');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (7, 5, 'Supervisor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (8, 5, 'Officer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (9, 5, 'Administrative Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (10, 5, 'Executive');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (11, 5, 'Clerk');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (12, 5, 'Human Resources Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (13, 5, 'Secretary / Front Office');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (14, 6, 'Agriculture & Farming Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (15, 6, 'Horticulturist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (16, 7, 'Pilot');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (17, 7, 'Air Hostess / Flight Attendant');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (18, 7, 'Airline Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (19, 8, 'Architect');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (20, 8, 'Interior Designer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (21, 9, 'Chartered Accountant');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (22, 9, 'Company Secretary');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (23, 9, 'Accounts / Finance Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (24, 9, 'Banking Service Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (25, 9, 'Auditor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (26, 9, 'Financial Accountant');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (27, 9, 'Financial Analyst / Planning');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (28, 9, 'Investment Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (29, 10, 'Fashion Designer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (30, 10, 'Beautician');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (31, 10, 'Hair Stylist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (32, 10, 'Jewellery designer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (33, 10, 'Designer (others)');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (34, 10, 'Makeup Artist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (35, 11, 'BPO / KPO / ITes Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (36, 11, 'Customer Service Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (37, 12, 'Civil Services (IAS / IES / IFS / IPS / IRS)');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (38, 13, 'Analyst');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (39, 13, 'Consultant');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (40, 13, 'Corporate Communication');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (41, 13, 'Corporate Planning');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (42, 13, 'Marketing Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (43, 13, 'Operations Management');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (44, 13, 'Sales Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (45, 13, 'Senior Manager / Manager');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (46, 13, 'Subject Matter Expert');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (47, 13, 'Business Development Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (48, 13, 'Content Writer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (49, 14, 'Army');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (50, 14, 'Navy');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (51, 14, 'Defence Services (Others)');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (52, 14, 'Air Force');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (53, 14, 'Paramilitary');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (54, 15, 'Professor / Lecturer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (55, 15, 'Teaching / Academician');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (56, 15, 'Education Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (57, 15, 'Training Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (58, 15, 'Research Assistant');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (59, 15, 'Research Scholar');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (60, 16, 'Civil Engineer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (61, 16, 'Electronics / Telecom Engineer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (62, 16, 'Mechanical / Production Engineer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (63, 16, 'Quality Assurance Engineer - Non IT');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (64, 16, 'Engineer - Non IT');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (65, 16, 'Designer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (66, 16, 'Product Manager - Non IT');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (67, 16, 'Project Manager - Non IT');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (68, 17, 'Hotel / Hospitality Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (69, 17, 'Restaurant / Catering Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (70, 17, 'Chef / Cook');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (71, 18, 'Software Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (72, 18, 'Hardware Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (73, 18, 'Product Manager');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (74, 18, 'Project Manager');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (75, 18, 'Program Manager');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (76, 18, 'Animator');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (77, 18, 'Cyber / Network Security');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (78, 18, 'UI / UX Designer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (79, 18, 'Web / Graphic Designer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (80, 18, 'Software Consultant');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (81, 18, 'Data Analyst');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (82, 18, 'Data Scientist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (83, 18, 'Network Engineer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (84, 18, 'Quality Assurance Engineer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (85, 19, 'Lawyer & Legal Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (86, 19, 'Legal Assistant');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (87, 20, 'Law Enforcement Officer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (88, 20, 'Police');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (89, 21, 'Doctor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (90, 21, 'Healthcare Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (91, 21, 'Paramedical Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (92, 21, 'Nurse');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (93, 21, 'Pharmacist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (94, 21, 'Physiotherapist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (95, 21, 'Psychologist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (96, 21, 'Veterinary Doctor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (97, 21, 'Dentist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (98, 21, 'Surgeon');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (99, 21, 'Therapist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (100, 21, 'Medical Transcriptionist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (101, 21, 'Dietician / Nutritionist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (102, 21, 'Lab Technician');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (103, 22, 'Journalist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (104, 22, 'Media Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (105, 22, 'Entertainment Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (106, 22, 'Event Management Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (107, 22, 'Advertising / PR Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (108, 22, 'Designer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (109, 22, 'Actor / Model');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (110, 22, 'Artist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (111, 23, 'Mariner / Merchant Navy');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (112, 23, 'Sailor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (113, 24, 'Scientist / Researcher');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (114, 25, 'CXO / President, Director, Chairman');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (115, 25, 'VP / AVP / GM / DGM / AGM');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (116, 26, 'Technician');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (117, 26, 'Arts & Craftsman');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (118, 26, 'Librarian');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (119, 26, 'Business Owner / Entrepreneur');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (120, 26, 'Transportation / Logistics Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (121, 26, 'Agent / Broker / Trader');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (122, 26, 'Contractor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (123, 26, 'Fitness Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (124, 26, 'Security Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (125, 26, 'Social Worker / Volunteer / NGO');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (126, 26, 'Sportsperson');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (127, 26, 'Travel Professional');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (128, 26, 'Singer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (129, 26, 'Writer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (130, 26, 'Politician');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (131, 26, 'Associate');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (132, 26, 'Builder');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (133, 26, 'Chemist');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (134, 26, 'CNC Operator');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (135, 26, 'Distributor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (136, 26, 'Driver');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (137, 26, 'Freelancer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (138, 26, 'Mechanic');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (139, 26, 'Medical Representative');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (140, 26, 'Musician');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (141, 26, 'Photo / Videographer');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (142, 26, 'Surveyor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (143, 26, 'Tailor');
INSERT INTO `occ_category_list` (`id`, `category_id`, `name`) VALUES (144, 26, 'Others');


#
# TABLE STRUCTURE FOR: pa_session
#

DROP TABLE IF EXISTS `pa_session`;

CREATE TABLE `pa_session` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3bf7hunos3kt3cjqumn224i88aen5apk', '::1', 1585204316, '__ci_last_regenerate|i:1585204316;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca7j5rfgqcvd44l14d9uprvpvao30agi', '::1', 1585204685, '__ci_last_regenerate|i:1585204685;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('obdk3ai94qha7jh65q2en29s13hi22vk', '::1', 1585205288, '__ci_last_regenerate|i:1585205288;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2mp7abe7rgb1l1iqef1ct1s827jdnebt', '::1', 1585206305, '__ci_last_regenerate|i:1585206305;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86ld6mfqod0t7kkcsaml4etv2dmrvp4a', '::1', 1585207164, '__ci_last_regenerate|i:1585207164;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('leda697d8uikclq1deov4vun8dvdq1sk', '::1', 1585207835, '__ci_last_regenerate|i:1585207835;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04tdg6622rua8fs2vo9r8n3hcse8binc', '::1', 1585208149, '__ci_last_regenerate|i:1585208149;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qdkarojfc86cc9jll3j8arjl0ruboaiq', '::1', 1585211152, '__ci_last_regenerate|i:1585211152;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5h0a8n0erhcbd7c5tjg236rl2or57shh', '::1', 1585211594, '__ci_last_regenerate|i:1585211594;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bi67u8jj9hhums754jgtga3q3h419qgd', '::1', 1585212035, '__ci_last_regenerate|i:1585212035;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p1ph4qno3mem26ju7qbbrar0fe1iqcf3', '::1', 1585213828, '__ci_last_regenerate|i:1585213828;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tncqud8es1ovb7sakci2o31vlh1vsuee', '::1', 1585214678, '__ci_last_regenerate|i:1585214678;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sadlj5l88ae8e29cgcvf164kgupv29nr', '::1', 1585215983, '__ci_last_regenerate|i:1585215983;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('al6taigpps74ef7sjh6vqg2kv76oi6ti', '::1', 1585217179, '__ci_last_regenerate|i:1585217179;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s812lvjjl88npegajkpj86vjvco6igv9', '::1', 1585217524, '__ci_last_regenerate|i:1585217524;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n3n1n4f48i50l4t58p1pgsmq3oi1hufi', '::1', 1585218124, '__ci_last_regenerate|i:1585218124;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('579dro5nqmju8js115uck7ut1ofvbdn1', '::1', 1585218693, '__ci_last_regenerate|i:1585218693;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uifuuhes3sgg85427qg6e2bnoui35ga7', '::1', 1585219003, '__ci_last_regenerate|i:1585219003;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0i5bs33an6taqa8kj50focn6hs436mh7', '::1', 1585219309, '__ci_last_regenerate|i:1585219309;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i2bk2ump5l9uboghnprk61bksup2npgv', '::1', 1585219613, '__ci_last_regenerate|i:1585219613;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cvjkkrdltdj078t6r12ge0hjde1erfqv', '::1', 1585220141, '__ci_last_regenerate|i:1585220141;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sntdv7qt220soelcrobbclkriq40e8b8', '::1', 1585226125, '__ci_last_regenerate|i:1585226125;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hinrqpo49b61errrpnnh6dgp5j8p25fl', '::1', 1585226709, '__ci_last_regenerate|i:1585226709;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rldf3qm0hpeasi3gp7c71j2qcqaansur', '::1', 1585226709, '__ci_last_regenerate|i:1585226709;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hp9oiskokkf3anvlm50qcvrhser72eip', '::1', 1585406665, '__ci_last_regenerate|i:1585406572;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('snthkojmda4j4gij7lqfclc6am13i8ci', '::1', 1585562251, '__ci_last_regenerate|i:1585562251;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"70\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0jdqem8a6o5lu8ug67i77798h80adfjb', '::1', 1585562552, '__ci_last_regenerate|i:1585562552;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"70\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('146gm5in9lf3ahbt38v6mqclg804re4j', '::1', 1585563068, '__ci_last_regenerate|i:1585563068;username|s:26:\"robinroyabraham1@gmail.com\";email|s:26:\"robinroyabraham1@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9fjr2n5e4u1i25t0lnqjg2f8hkerorun', '::1', 1585563254, '__ci_last_regenerate|i:1585563068;username|s:26:\"robinroyabraham1@gmail.com\";email|s:26:\"robinroyabraham1@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d22cqrooa2fauqlkqg3n1gklnj7he2bu', '::1', 1585898918, '__ci_last_regenerate|i:1585898918;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gtg8b84ih43dt0vsbr50qa8lkftgtnkk', '::1', 1585922166, '__ci_last_regenerate|i:1585922166;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6v2b48oiu8skim909b8i08r7a3m7691d', '::1', 1585922575, '__ci_last_regenerate|i:1585922575;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tsf78ne31gtp1vt03jkiru3md8bseu1d', '::1', 1585923580, '__ci_last_regenerate|i:1585923580;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7rute6k8o0ksdjm9mn2rqqc16qeu43fo', '::1', 1585923884, '__ci_last_regenerate|i:1585923884;username|s:26:\"robinroyabraham1@gmail.com\";email|s:26:\"robinroyabraham1@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mqs5tub21m9csujq0p74tr91baoncnlm', '::1', 1585924413, '__ci_last_regenerate|i:1585924413;msg|s:56:\"Please check your email or SMS to activate your account!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cnjf9asbp9pub4838r8rl59kiu1m30as', '::1', 1585927205, '__ci_last_regenerate|i:1585927205;msg|s:56:\"Please check your email or SMS to activate your account!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8gver9dbmh794tnfp73bot5rdqjr3mt5', '::1', 1585927793, '__ci_last_regenerate|i:1585927793;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"79\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebrcpuqqsd4lkg0gtrl5adankkvktg70', '::1', 1585928853, '__ci_last_regenerate|i:1585928853;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l4q8r9hi43rkqncbp8bu67eel4m1kv03', '::1', 1585929180, '__ci_last_regenerate|i:1585929180;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('clpv0t063kbkffic66sj3keat23n50td', '::1', 1585929264, '__ci_last_regenerate|i:1585929180;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s80pc95dhuhq79ns29l5dku718l6kcde', '::1', 1585973254, '__ci_last_regenerate|i:1585973254;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ilfri25h8uplnsjj12mr1b7sprv34m3', '::1', 1586068433, '__ci_last_regenerate|i:1586068433;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"70\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ifvt97peapvvtvqc3a7ctuiu3cmj61ju', '::1', 1586068765, '__ci_last_regenerate|i:1586068765;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"70\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1rljgsinb8bmkgilk1jb2b0mn0pra46f', '::1', 1586069179, '__ci_last_regenerate|i:1586069179;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"70\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1peib42bf2d902f6kphg86cdln37c25u', '::1', 1586069878, '__ci_last_regenerate|i:1586069878;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uv6o0m3tqqdupe2s8ai0q234bbne1eel', '::1', 1586070385, '__ci_last_regenerate|i:1586070385;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qn3ah20i36gkufvb71pujvj0s10uqkev', '::1', 1586070762, '__ci_last_regenerate|i:1586070762;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rh0h7c0co888um007rhubk3rgkv63hjd', '::1', 1586071167, '__ci_last_regenerate|i:1586071167;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gv32vk5hgpp6na7t5jg892gd7024fhe4', '::1', 1586072653, '__ci_last_regenerate|i:1586072653;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('thc71tufh7jjbv6p23g8411rpljo51si', '::1', 1586072755, '__ci_last_regenerate|i:1586072653;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dpmttckcrke12uabj28tb76tfbhnq0mh', '::1', 1586176944, '__ci_last_regenerate|i:1586176944;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ugpbvkiig07ro36o6fuhhbv536ntnsg7', '::1', 1586177614, '__ci_last_regenerate|i:1586177614;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6imj8qrt1g48bang1uu2r5c1qinivge7', '::1', 1586178936, '__ci_last_regenerate|i:1586178936;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6e88h1fe0qf2ripjeteuda5qnk55264v', '::1', 1586179283, '__ci_last_regenerate|i:1586179283;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2pusc1osb3m4jm11aufhpf5d5s6ca37m', '::1', 1586180059, '__ci_last_regenerate|i:1586180059;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bit8ied4c0ccq7a3ip121nrgnnl8i4ir', '::1', 1586180460, '__ci_last_regenerate|i:1586180460;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nu3gd16lvq7osp8lfso6nnvrjb6r5ph1', '::1', 1586180703, '__ci_last_regenerate|i:1586180460;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hba38hvtln20a9m8f6qb06shu83ski43', '::1', 1586188987, '__ci_last_regenerate|i:1586188987;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64hk4nb8q6jnk8dtntib3ucbo0bretpg', '::1', 1586189281, '__ci_last_regenerate|i:1586189216;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n1ug05jpc8rjcsgjq3a14vkplea6asor', '::1', 1586335865, '__ci_last_regenerate|i:1586335862;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pus54kki9bkhlnoir3qdoqbj9d6egopd', '::1', 1586407452, '__ci_last_regenerate|i:1586407452;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dmgnkrpdv40bcd92qaimmvnb7b2fn5gn', '::1', 1586434834, '__ci_last_regenerate|i:1586434834;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kv9mcbmfn8784o4vhf1jt8a7sumgr10g', '::1', 1586435202, '__ci_last_regenerate|i:1586435202;username|s:15:\"jeena@gmail.com\";email|s:15:\"jeena@gmail.com\";user_id|s:2:\"80\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1mlf5epe77q87u5a3qiu7kcmrs4h5mol', '::1', 1586435717, '__ci_last_regenerate|i:1586435717;username|s:15:\"jeena@gmail.com\";email|s:15:\"jeena@gmail.com\";user_id|s:2:\"80\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o0v66615tss2obhjq957lkghaon8kj58', '::1', 1586436780, '__ci_last_regenerate|i:1586436780;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be78td70sct73tcqu63q677o54qfdrhf', '::1', 1586437094, '__ci_last_regenerate|i:1586437094;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mmfjt1ddmvn6ioeuk8rn6j6arfimq86r', '::1', 1586440826, '__ci_last_regenerate|i:1586440826;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ateoktd8g7s6ieclekf8vv0udcs89rh2', '::1', 1586440851, '__ci_last_regenerate|i:1586440826;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('00bbsdep7mi92unmbaq16pgcl3ci8jpd', '::1', 1586453334, '__ci_last_regenerate|i:1586453334;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tphicdgq9e62u2a9uv5att4hkq7tfbs8', '::1', 1586453769, '__ci_last_regenerate|i:1586453531;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"85\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37ifqbpbfornh06qo02k2trr1ucdeeel', '::1', 1586604994, '__ci_last_regenerate|i:1586604994;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"86\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ue2ob2670ge9p46rd2qes262bd1e7l75', '::1', 1586606579, '__ci_last_regenerate|i:1586606579;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jn1rt7fuf8r81dul8ruhf4spdiis7ccq', '::1', 1586606584, '__ci_last_regenerate|i:1586606579;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d2jc6g5ch1ab0jt8kh9gfoiobpcvf9q', '::1', 1586757801, '__ci_last_regenerate|i:1586757801;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"86\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r31k1viblpud48du9f3028ho470q0a98', '::1', 1586758375, '__ci_last_regenerate|i:1586758375;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"86\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3mph389fqvcqbhbmjnfromppipj80ikh', '::1', 1586758532, '__ci_last_regenerate|i:1586758375;username|s:26:\"robinroyabraham1@gmail.com\";email|s:26:\"robinroyabraham1@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f5v3uc2g662ls16pbv9u0sdkuv5lr6q5', '::1', 1586940300, '__ci_last_regenerate|i:1586940300;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ulu4k6plqbkd92u04ij265bm03dr7jq', '::1', 1586941317, '__ci_last_regenerate|i:1586941317;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ufl7pf4nvibvebs79bkppf0tp4pf7284', '::1', 1586948477, '__ci_last_regenerate|i:1586948477;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66nq419hndaglbso8e94u3o9u5bj3kgr', '::1', 1586948778, '__ci_last_regenerate|i:1586948778;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"87\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fqmn014vgrtjj58412eo89aeklh5lioo', '::1', 1586948821, '__ci_last_regenerate|i:1586948821;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('njdmt7djuss9daahn92neqk2s3qgtpii', '::1', 1586956418, '__ci_last_regenerate|i:1586956413;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('48o0nvgguj2lsppm0hanemif7gu1iuik', '::1', 1587011126, '__ci_last_regenerate|i:1587011126;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qvenikavgipd5o7cn451bqpje3s7200k', '::1', 1587011463, '__ci_last_regenerate|i:1587011463;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9p6le3rh8b81q3btcl3262u9u3anathh', '::1', 1587013188, '__ci_last_regenerate|i:1587013188;msg|s:56:\"Please check your email or SMS to activate your account!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cagkesmh7a72a026aecnmpeb5k59ec90', '::1', 1587015182, '__ci_last_regenerate|i:1587015182;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a76a29rv7a3910q2i6uo6f6ue473j0s', '::1', 1587015618, '__ci_last_regenerate|i:1587015618;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n90avl2lq7ir7hplovb44k1bjnbej7q9', '::1', 1587015980, '__ci_last_regenerate|i:1587015980;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ojkke60btt1ovnfplgk0mkf19hobc7ba', '::1', 1587017060, '__ci_last_regenerate|i:1587017060;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2edpd5mo6apjhbtvhvva9m9lhuffjtje', '::1', 1587017383, '__ci_last_regenerate|i:1587017383;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lp6g6tv1rek49bo1n5rbp8hvspleqj2e', '::1', 1587021670, '__ci_last_regenerate|i:1587021670;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rpb1mtn48j4vr77rqrptlneli2ut827i', '::1', 1587022128, '__ci_last_regenerate|i:1587022128;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p8lv3ihsh5k8ekc786uitqmatipdoijh', '::1', 1587022128, '__ci_last_regenerate|i:1587022128;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('igt95dqseadbd3mnordkfibgtmi4cubi', '::1', 1587032013, '__ci_last_regenerate|i:1587032013;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('41jtcn67v5sf0kb8kjc5t6jighg5hph6', '::1', 1587032370, '__ci_last_regenerate|i:1587032370;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j9qsvioul4ejhcqui7b05aj5jmm0vve2', '::1', 1587032855, '__ci_last_regenerate|i:1587032855;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('imnccq0n9svqttvsbs7jl0jri8ofq2al', '::1', 1587033175, '__ci_last_regenerate|i:1587033175;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4uk3qnto0aeersbqt3h62d6e7tu7p34n', '::1', 1587033489, '__ci_last_regenerate|i:1587033489;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3qnupvv9aagt6df5j19u0026t1tgldue', '::1', 1587033797, '__ci_last_regenerate|i:1587033797;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qh1mkmjua9cr6npqv1rn4sl9ce732g1c', '::1', 1587034003, '__ci_last_regenerate|i:1587033797;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"89\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('708oil8h6taaodtk0qu4jmtj4hs0f1em', '::1', 1588851393, '__ci_last_regenerate|i:1588851393;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('deilqeescv4oagclf1rhoiadt6vn33ov', '::1', 1588851393, '__ci_last_regenerate|i:1588851393;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0j6kvfvompnblnni0ohupvvokrtp4b7t', '::1', 1590733595, '__ci_last_regenerate|i:1590733576;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9fg1nchl4l4d4qgenoa1l3be1kuibprn', '::1', 1591205072, '__ci_last_regenerate|i:1591205071;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6hs4m486omqksmde4f07ke6phj2qlkpr', '::1', 1591688248, '__ci_last_regenerate|i:1591688230;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ie0k3u9eplld1hpp9d2i6e8kf3unmv1', '::1', 1591702284, '__ci_last_regenerate|i:1591702246;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1rs6evms2qoh0mj6d0kphn1oou74i2en', '::1', 1601094328, '__ci_last_regenerate|i:1601094328;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v7f1rsmot8q9iju59fjlv7f1i6272hlt', '::1', 1601094728, '__ci_last_regenerate|i:1601094728;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('djb13ofkulsqpdjba36t3u8n0im9eqkm', '::1', 1601096449, '__ci_last_regenerate|i:1601096449;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hehntin0vi28lr3b6h233v50gf5j2nsu', '::1', 1601097107, '__ci_last_regenerate|i:1601097107;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32nu8sitgbt72in25odrpt41dc5paaj5', '::1', 1601098610, '__ci_last_regenerate|i:1601098610;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5r3fgt73a34hmr0eve5b0ur7280lcogm', '::1', 1601099071, '__ci_last_regenerate|i:1601099071;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('43madl17tvm04cuh3mti96epncm7n20s', '::1', 1601099425, '__ci_last_regenerate|i:1601099425;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pl8m4ef0gohak4q956u8dagg4g0ni9m9', '::1', 1601099771, '__ci_last_regenerate|i:1601099771;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qe39ijp1fvkvbrhotfmvcpflphghcfbq', '::1', 1601100121, '__ci_last_regenerate|i:1601100121;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lrvv2qg9mkdo7mlvlf06gfhs595i5m28', '::1', 1601101395, '__ci_last_regenerate|i:1601101395;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gi6p7k4t0j9ihkll7chjf3f6dg3di2hb', '::1', 1601101972, '__ci_last_regenerate|i:1601101972;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mua1k117k6idhr03fagu26c514m0mnna', '::1', 1601102286, '__ci_last_regenerate|i:1601102286;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6qe520kqmf1j78rmmvh2sptlssvt6cde', '::1', 1601102643, '__ci_last_regenerate|i:1601102643;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5l7gl0fp05plt8pt91pf15acrsuhct2i', '::1', 1601102959, '__ci_last_regenerate|i:1601102959;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1lj4u3345m2aogq0leq17ncp240u2fas', '::1', 1601103278, '__ci_last_regenerate|i:1601103278;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l8cs1itqo89fk4kequvmieie39r9g99u', '::1', 1601104036, '__ci_last_regenerate|i:1601104036;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d09m6vkhg9jbv89j0n2gfeqs9vrpsvln', '::1', 1601104395, '__ci_last_regenerate|i:1601104395;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('anj5gdqnoeriqrit8c4i20c794odi0c2', '::1', 1601104764, '__ci_last_regenerate|i:1601104764;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aotm0o09q7qpq5hqc5su7t2g97ricsq7', '::1', 1601109818, '__ci_last_regenerate|i:1601109818;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j8pi6cabsm4qltl02a8ah8a3eqmk5lq3', '::1', 1601110120, '__ci_last_regenerate|i:1601110120;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qq71cuqn48h3clfaa5b9tcsb4ngbbb02', '::1', 1601110571, '__ci_last_regenerate|i:1601110571;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1dqrv1lc30tl70k4apbt0tv5fpq00s6a', '::1', 1601111792, '__ci_last_regenerate|i:1601111792;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6oq7hkg4m5sssd0khsr04k1htije0215', '::1', 1601112101, '__ci_last_regenerate|i:1601112101;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r1krecafomce2foj5tonuetrfrl4ne3a', '::1', 1601112450, '__ci_last_regenerate|i:1601112450;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rehhsf16uo2rt3jh727our5ns2eb14kv', '::1', 1601112766, '__ci_last_regenerate|i:1601112766;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ee00al5n0v3k92gnusde6vi8en6uhf88', '::1', 1601113411, '__ci_last_regenerate|i:1601113411;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5knv7772tn3dli39vbbq98n5r70acq8h', '::1', 1601115033, '__ci_last_regenerate|i:1601115033;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7fpokbtg39gqcho6lcnfqt5bvcnhsf5c', '::1', 1601115839, '__ci_last_regenerate|i:1601115839;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5vndp2oumtcb1hmigf72u4k5an5c23es', '::1', 1601116138, '__ci_last_regenerate|i:1601115839;username|s:24:\"robin.smartipz@gmail.com\";email|s:24:\"robin.smartipz@gmail.com\";user_id|s:2:\"91\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('176tp2a43kq1k8n6sfv16fik10h8tprd', '::1', 1602054048, '__ci_last_regenerate|i:1602054048;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2ajr5tmpfh0tn27h41o7lgu1egf5nbs', '::1', 1602060262, '__ci_last_regenerate|i:1602060262;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gt16mt25gskb5r1414juage9nohfvpmt', '::1', 1602060767, '__ci_last_regenerate|i:1602060767;username|s:26:\"robinroyabraham1@gmail.com\";email|s:26:\"robinroyabraham1@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";msg|s:30:\"Settings updated successfully!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k4iec4eormljo09qem087luoba8jdiea', '::1', 1602061306, '__ci_last_regenerate|i:1602061306;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v6v2lc74se3jh5f0gt91oktr1ni6i9ds', '::1', 1602061379, '__ci_last_regenerate|i:1602061306;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qj4ml3mt0o75u8qo1e194pof5d46ocio', '::1', 1602139634, '__ci_last_regenerate|i:1602139634;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2h9lvs3g4v9st8hvtthqafl95cb9bros', '::1', 1602139937, '__ci_last_regenerate|i:1602139937;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('id0t2ofureo7lk0agi0nqt7v5d20eq9r', '::1', 1602140280, '__ci_last_regenerate|i:1602140280;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"57\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l6sbb7hmb5st4tmu1q38sk6ladu5olbu', '::1', 1602141938, '__ci_last_regenerate|i:1602141938;username|s:26:\"robinroyabraham1@gmail.com\";email|s:26:\"robinroyabraham1@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";msg|s:30:\"Settings updated successfully!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n327e3o6r3gnfo2possv60qamoo1kd0o', '::1', 1602141971, '__ci_last_regenerate|i:1602141968;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4047447c193a506c52d750056c82822a2e29b4a1', '43.229.88.182', 1664637124, '__ci_last_regenerate|i:1664637124;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1d1ecfea0a31aef5d49f371446fe823781b994d7', '137.97.123.69', 1664637494, '__ci_last_regenerate|i:1664637241;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bffba83ce1ef3c5623a483aaf97dc64081d9c77f', '43.229.88.182', 1664637475, '__ci_last_regenerate|i:1664637475;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('732258443d1e56bc3a9087319672a8eef82dd00c', '137.97.123.69', 1664637241, '__ci_last_regenerate|i:1664637241;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1225d3ff53b54ddb7875753a7b371d5d3a87f3b3', '43.229.88.182', 1664637634, '__ci_last_regenerate|i:1664637475;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b1dd80ea2396aa8a966d24a3d038c2ef5c866c4', '45.87.9.207', 1664640961, '__ci_last_regenerate|i:1664640961;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eed71a05a2db7a9e9ae01bea584597ff9cd998d7', '45.87.9.45', 1664641106, '__ci_last_regenerate|i:1664641106;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18bceaefbecea19a89083eb215a5832fd7c54e6e', '20.246.32.188', 1664654623, '__ci_last_regenerate|i:1664654623;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a30315ff3b6b7756b2dd5b9a7e8d1b9f11a612ee', '45.87.9.13', 1664655341, '__ci_last_regenerate|i:1664655341;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86fb34724c7fdf34e830542b225da1c338115e74', '65.154.226.167', 1664666487, '__ci_last_regenerate|i:1664666487;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('42738cae953d2535e44774862d7fddd5003070b8', '45.87.9.156', 1664669899, '__ci_last_regenerate|i:1664669899;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3f54646df8a55a8ac514c98786a41f53f56d62b7', '45.115.91.151', 1664683919, '__ci_last_regenerate|i:1664683919;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6065889b634df9091ae05aaf86c144d105798e32', '45.87.9.15', 1664683672, '__ci_last_regenerate|i:1664683671;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e884839b3d5eb5084c5817e3304e52c9e7eb3fa', '45.115.91.151', 1664683919, '__ci_last_regenerate|i:1664683919;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad7e9f454bafd0ac5fc609b7104ffeaff08d6bbb', '45.87.9.126', 1664702657, '__ci_last_regenerate|i:1664702657;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a822b29b0c4279051e7517c0d8807e079c77c84', '45.87.9.60', 1664720804, '__ci_last_regenerate|i:1664720804;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('17035b550a8ba46b0b39ae7c55b9f1fca010f504', '51.255.62.1', 1664725962, '__ci_last_regenerate|i:1664725962;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfe715d1eafabeef7d036e68aef322fe9c7aa90d', '51.255.62.1', 1664725964, '__ci_last_regenerate|i:1664725964;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('550fcd578d5b68c037684146657e0ee6fc25a806', '51.254.49.104', 1664732357, '__ci_last_regenerate|i:1664732357;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b1f3ac436ea32232d2249d5f56fcad01fd4f8909', '137.97.123.69', 1664734615, '__ci_last_regenerate|i:1664734615;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80b32fd2f5dd3f12189ca0ee85694564106e4d44', '137.97.123.69', 1664734926, '__ci_last_regenerate|i:1664734926;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ac457f97c1d5be472dd629001c12b45081c88445', '137.97.123.69', 1664734937, '__ci_last_regenerate|i:1664734926;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('28d9c06c8ce341685fa749247aa19f67c840330c', '45.87.9.30', 1664748739, '__ci_last_regenerate|i:1664748739;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dd413b06b258a5cdc83858d96e00942954506e5f', '49.44.80.39', 1664752426, '__ci_last_regenerate|i:1664752426;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e214bfeaffae26750f3ce5dbc09ebe903b38d08f', '103.70.197.89', 1664769823, '__ci_last_regenerate|i:1664769823;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f8c764e595682c6947e9371fa12a3efacc781030', '103.70.197.89', 1664770503, '__ci_last_regenerate|i:1664770503;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('083a1ddaf9dcde011a40747f047b4bcea350cd8a', '103.70.197.89', 1664774892, '__ci_last_regenerate|i:1664774892;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('852f81402e23e631ef0a64ec86ba2b27ef3e5492', '45.87.9.205', 1664770682, '__ci_last_regenerate|i:1664770682;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('af71117259a3fe93a5cd2ec234c8652004b94bb7', '111.92.29.225', 1664771289, '__ci_last_regenerate|i:1664771289;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12346cf1a41ed50ef43db555c3ee294fea183b27', '111.92.29.225', 1664771625, '__ci_last_regenerate|i:1664771625;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('de197294a5e8a7071b59eafd66170359d314771f', '111.92.29.225', 1664772503, '__ci_last_regenerate|i:1664772503;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad39152e0ba31037f9233f2308fa7b4b9eacb5f5', '111.92.29.225', 1664774917, '__ci_last_regenerate|i:1664774917;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa73a30028a4fdb4fedec47be68f1ec484f7ace7', '111.92.29.225', 1664775288, '__ci_last_regenerate|i:1664775288;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b9802d0d70880563324e54095008cadc7f1ae3b4', '103.70.197.89', 1664775762, '__ci_last_regenerate|i:1664775762;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('de3ba65a720be624a8376017923505fef0e954d2', '111.92.29.225', 1664775790, '__ci_last_regenerate|i:1664775790;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('89d20ef86469614be2d4f7e8c81942e549f25c7f', '111.92.29.225', 1664776133, '__ci_last_regenerate|i:1664776133;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0c36468678a5b3db976ecb9396d833b95ee1a3f', '111.92.29.225', 1664776302, '__ci_last_regenerate|i:1664776018;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b177c4d4213bc9c8437cb7ab6d6082992b93ec6', '103.70.197.89', 1664779512, '__ci_last_regenerate|i:1664779512;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbb689f03a2b33896a6fc9c4088d72b093e29366', '111.92.29.225', 1664776631, '__ci_last_regenerate|i:1664776631;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa6f6efcbebd38240597d1ec1aaa69365305e067', '111.92.29.225', 1664776685, '__ci_last_regenerate|i:1664776685;username|s:24:\"jesna.smartipz@gmail.com\";email|s:24:\"jesna.smartipz@gmail.com\";user_id|s:2:\"96\";logged_in|b:1;group_id|s:1:\"2\";msg|s:43:\"Personal informations updated successfully!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d6908e1860c33142424f81e0e44bab89848c8b7', '111.92.29.225', 1664777000, '__ci_last_regenerate|i:1664777000;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('984ad52430d72db6219bfab6f130152643edfa0a', '111.92.29.225', 1664778080, '__ci_last_regenerate|i:1664778080;username|s:24:\"jesna.smartipz@gmail.com\";email|s:24:\"jesna.smartipz@gmail.com\";user_id|s:2:\"96\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9268a5173cb7807231536f20a4fa3c080ba80090', '49.44.82.235', 1664776702, '__ci_last_regenerate|i:1664776700;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eafb016eaae3e3570bcae5ef7be8186023a98198', '111.92.29.225', 1664777041, '__ci_last_regenerate|i:1664777000;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('732f0912679143c177fd9f32d2168ce5f73832cb', '183.82.15.167', 1664777689, '__ci_last_regenerate|i:1664777659;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d099bc3331e93de9ff2013c02f1536544b33978', '111.92.29.225', 1664778083, '__ci_last_regenerate|i:1664778080;username|s:24:\"jesna.smartipz@gmail.com\";email|s:24:\"jesna.smartipz@gmail.com\";user_id|s:2:\"96\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f5189368a23c6b2856b303e0b8ceda8f4449ce2', '103.70.197.89', 1664779888, '__ci_last_regenerate|i:1664779888;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9a74bdaeb07f9ef723391251f4f15180762f7279', '103.70.197.89', 1664780192, '__ci_last_regenerate|i:1664780192;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f71bcaaa11cff64f2bad6997526534adf98e944a', '111.92.29.225', 1664780154, '__ci_last_regenerate|i:1664780114;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6165c274a3d42d8b2450495ddabd4c71ad49125d', '111.92.29.225', 1664780481, '__ci_last_regenerate|i:1664780481;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0053554f40358e57129d0fad9824e17b055dea09', '103.70.197.89', 1664780602, '__ci_last_regenerate|i:1664780602;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddfc5e5f46debfc119fd226c9ae773c4e511f64b', '111.92.29.225', 1664780817, '__ci_last_regenerate|i:1664780817;username|s:25:\"akhila.smartipz@gmail.com\";email|s:25:\"akhila.smartipz@gmail.com\";user_id|s:2:\"97\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ae215c3d604dac8394e4b5e6f662cca6afecaba3', '103.70.197.89', 1664782644, '__ci_last_regenerate|i:1664782644;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5784ccad5c17d970045f253d134a893346d0d8db', '111.92.29.225', 1664780923, '__ci_last_regenerate|i:1664780791;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5aacd27e999515600277d68993d237ce3988bb67', '111.92.29.225', 1664780953, '__ci_last_regenerate|i:1664780817;username|s:25:\"akhila.smartipz@gmail.com\";email|s:25:\"akhila.smartipz@gmail.com\";user_id|s:2:\"97\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0c9cff1140cc0a847c808787b3a84e5f8ae5b724', '49.44.81.233', 1664781799, '__ci_last_regenerate|i:1664781774;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2f1755ebba7907eee0e459db4592bf64be5f9867', '103.70.197.89', 1664788477, '__ci_last_regenerate|i:1664788477;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e752ce5a1319b2f577ad73b4570481a0f8b7e9f7', '103.70.197.89', 1664788494, '__ci_last_regenerate|i:1664788477;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9a4ba3e302399045a7836869bc006be0174976da', '1.39.76.26', 1664794879, '__ci_last_regenerate|i:1664794879;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0aaae8632ad562007e14321745ba3ff36b7f2c7', '45.87.9.60', 1664795299, '__ci_last_regenerate|i:1664795299;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('557d62006bd16fd3710b13c13441a6214472f3e7', '202.134.182.134', 1664799170, '__ci_last_regenerate|i:1664799168;msg|s:29:\"Your activation key expired. \";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2415b280b627bebd61f468f4b8668b3068586cb', '45.87.9.220', 1664806086, '__ci_last_regenerate|i:1664806086;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('181c387655d9c14cb3a975f5cf09a379a25bb8e2', '42.104.157.203', 1664807936, '__ci_last_regenerate|i:1664807936;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be100292960898412799f35d9634024ea954a826', '203.171.242.4', 1664810236, '__ci_last_regenerate|i:1664810234;msg|s:29:\"Your activation key expired. \";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('620aaf75cc9d3263bd3ef36e1f6a429afafe668a', '103.70.197.89', 1664813951, '__ci_last_regenerate|i:1664813947;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('556583f9e243bd118b0a89a07babc5202065175b', '45.87.9.239', 1664820919, '__ci_last_regenerate|i:1664820919;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f24ace98183eb179486059d8a1643af232809e7', '49.44.67.198', 1664824723, '__ci_last_regenerate|i:1664824720;msg|s:29:\"Your activation key expired. \";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('77afa0d59a42db1ec1d30f78e7d9441b74ba3395', '45.87.9.220', 1664838355, '__ci_last_regenerate|i:1664838355;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7517022ab3677b588fd0dd6050b2896f0bb3dd9d', '15.228.216.104', 1664853060, '__ci_last_regenerate|i:1664853060;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3efb49be41c859b7b269ae5c0bccb6e66cc90db7', '103.70.197.89', 1664859272, '__ci_last_regenerate|i:1664859081;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75e7c94dfaa5c1e94f11c38ddd358b042ae01a8f', '45.87.9.30', 1664870825, '__ci_last_regenerate|i:1664870825;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('59cd8b284f9cd8a9813415be419a8e6a7d6f9515', '45.87.9.175', 1664889078, '__ci_last_regenerate|i:1664889078;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f31aa6c27747c22f127f15b830dad13f8e2759e6', '45.87.9.190', 1664910545, '__ci_last_regenerate|i:1664910545;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cb052052df6ff82e16dd061bd352adb6c10855fe', '45.87.9.13', 1664932241, '__ci_last_regenerate|i:1664932241;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07b81a9f9a7f6f4f1a52b816ba276474946fee54', '157.44.138.16', 1664949427, '__ci_last_regenerate|i:1664949427;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";msg|s:30:\"Settings updated successfully!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5b9af566b519d479222401c42c9587f48c0721d2', '54.160.218.11', 1664949094, '__ci_last_regenerate|i:1664949094;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('79852a4dd44762e37d3edb741c26086f46d7d1be', '54.85.96.214', 1664949094, '__ci_last_regenerate|i:1664949094;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('750e731717876006299298fa385cd202c8774c9e', '54.86.145.155', 1664949094, '__ci_last_regenerate|i:1664949094;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('587066d5358fe4bf0364ab9be53f33a63c37db13', '54.163.10.248', 1664949094, '__ci_last_regenerate|i:1664949094;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7acd94c7aa8678b402e5a03215aed772a42f71e', '54.80.202.83', 1664949094, '__ci_last_regenerate|i:1664949094;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dcba4ad52b85a1ddc38e467c944a45ef0b384338', '52.207.252.233', 1664949130, '__ci_last_regenerate|i:1664949130;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87ecba632915420307c7c6d39075d2b9f8eee39c', '111.92.31.153', 1664952821, '__ci_last_regenerate|i:1664952821;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8efc28922a785607cdbf4a8a4ec160b5ccf6d2a4', '111.92.31.153', 1664953086, '__ci_last_regenerate|i:1664952821;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7b236a6480c22fa114598d4fc928de0f0751658', '45.87.9.13', 1664957463, '__ci_last_regenerate|i:1664957463;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e198c61943a88948290602194d16181c5d827505', '111.92.31.153', 1664961691, '__ci_last_regenerate|i:1664961572;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5b13032dbaf00e11d0cbe09a07a951fbd98f4c8', '45.87.9.60', 1664983217, '__ci_last_regenerate|i:1664983217;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('53dc551f511a9be588753db557e5fe512c00ebfc', '52.67.15.163', 1665011110, '__ci_last_regenerate|i:1665011110;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6c158bb593f8bff42a98843819736853da2050df', '111.92.30.201', 1665028792, '__ci_last_regenerate|i:1665028792;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ca13f4b0b3a20e20f05307b699ecca3d19ab7d1', '111.92.30.201', 1665029419, '__ci_last_regenerate|i:1665029419;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e4fca81bbf267091ba190937e2bf9cb4a9a860ac', '111.92.30.201', 1665031133, '__ci_last_regenerate|i:1665031133;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bf6a0a29d92f0f66bbb7bfb7faab7d6697f1d70', '111.92.30.201', 1665031438, '__ci_last_regenerate|i:1665031438;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ea8af5051e7ac50ce68755d4ca423b7db5c95da7', '111.92.30.201', 1665031393, '__ci_last_regenerate|i:1665031133;username|s:23:\"easa.smartipz@gmail.com\";email|s:23:\"easa.smartipz@gmail.com\";user_id|s:2:\"95\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ccde9ae9af437ab9c4a4432fee8fcd833e7edeff', '111.92.30.201', 1665031651, '__ci_last_regenerate|i:1665031438;msg|s:56:\"Please check your email or SMS to activate your account!\";__ci_vars|a:1:{s:3:\"msg\";s:3:\"old\";}');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7d5ce39fc31cc6cf99f8787d86fe150c80c695a4', '111.92.30.201', 1665042089, '__ci_last_regenerate|i:1665042089;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd2f7d3cf163e15c085d52ece594e4106a9bb01a', '52.67.2.104', 1665040435, '__ci_last_regenerate|i:1665040435;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a9416aaa03848c651695ebcfa8e6f923d15e9ac6', '111.92.30.201', 1665042089, '__ci_last_regenerate|i:1665042089;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8506ce242e24aded445d0d6a32e494e751bf0aeb', '45.87.9.94', 1665054742, '__ci_last_regenerate|i:1665054742;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d3b563c960d908ba76f20e334d8c18ddf155db05', '15.229.17.69', 1665069478, '__ci_last_regenerate|i:1665069478;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5da755e54e678716638231c61703e7e348638f82', '18.231.143.197', 1665087071, '__ci_last_regenerate|i:1665087071;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('43c1cd9d7c6b16b95aa2ca644d525977971ca1e6', '45.87.9.111', 1665105188, '__ci_last_regenerate|i:1665105188;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('91ed6ffacc193814e91e59409e0c55530e555bdd', '103.70.197.70', 1665111936, '__ci_last_regenerate|i:1665111861;username|s:25:\"robinroyabraham@gmail.com\";email|s:25:\"robinroyabraham@gmail.com\";user_id|s:2:\"92\";logged_in|b:1;group_id|s:1:\"2\";');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed7d7cc970d6c5ddf09fd4bae133a1b8b544ed30', '205.210.31.5', 1665115811, '__ci_last_regenerate|i:1665115811;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57a39c6f1aeeb947b860a52eea63d8b051ec6fb6', '45.87.9.141', 1665123077, '__ci_last_regenerate|i:1665123077;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('afde4a5ef1e50d11c3d31e65705c113190aaceba', '45.87.9.205', 1665140802, '__ci_last_regenerate|i:1665140802;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e45bf6d789a285843ac57691f83bceecb8b3c8b1', '45.87.9.111', 1665162391, '__ci_last_regenerate|i:1665162391;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('54d96247f5a6f1a056c48e431f6cf6e739287f47', '205.210.31.129', 1665170467, '__ci_last_regenerate|i:1665170467;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5f8177bf32e945bb10b18ce5d3fe3cc5ce908baa', '54.167.184.249', 1665173378, '__ci_last_regenerate|i:1665173378;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('501fac7410560fbfbaa683fe9d920bcc236e1cf2', '18.204.221.241', 1665173378, '__ci_last_regenerate|i:1665173378;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68875fbb25394bd80328d4059c5678e5ba212785', '34.203.246.248', 1665173378, '__ci_last_regenerate|i:1665173378;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('faa59134ef6d0f9e385d12afc7c92606ea06baf2', '35.174.105.216', 1665173378, '__ci_last_regenerate|i:1665173378;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a0e92c02afc803553e4e66d1710d0973bd94e06', '54.90.95.157', 1665173379, '__ci_last_regenerate|i:1665173379;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0507179634be0a1c1824c300c13b9fab5984a4ff', '54.152.86.38', 1665173380, '__ci_last_regenerate|i:1665173380;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4cf55c863200cb1155f8725114562f3610c7e803', '45.87.9.45', 1665181033, '__ci_last_regenerate|i:1665181033;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('60bd5a1ee3392849ea989b99c2484b8041d1cc79', '205.210.31.54', 1665181989, '__ci_last_regenerate|i:1665181989;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d04b1a180c44696fc9b0a71b0387facfebca802f', '45.87.9.252', 1665202632, '__ci_last_regenerate|i:1665202632;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa799e211b243339710849b2b1fd29896a937093', '198.235.24.50', 1665225248, '__ci_last_regenerate|i:1665225248;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bc5ed0eae934586530f2399c7b6c0adeaacd6985', '45.87.9.94', 1665227060, '__ci_last_regenerate|i:1665227060;');
INSERT INTO `pa_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cdf5662c1ea4510e7f803efbe6ae7d75b4c7c7d6', '111.92.30.177', 1665229210, '__ci_last_regenerate|i:1665229187;username|s:24:\"knanayapartner@gmail.com\";email|s:24:\"knanayapartner@gmail.com\";user_id|s:2:\"15\";logged_in|b:1;group_id|s:1:\"1\";');


#
# TABLE STRUCTURE FOR: profectional_details
#

DROP TABLE IF EXISTS `profectional_details`;

CREATE TABLE `profectional_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `edu_cat` int(11) NOT NULL,
  `edu_item` int(11) NOT NULL,
  `occ_cat` int(11) NOT NULL,
  `employed_in` int(11) NOT NULL,
  `occ_item` int(11) NOT NULL,
  `occ_description` text NOT NULL,
  `income_symbol` varchar(50) NOT NULL,
  `annual_income` varchar(255) NOT NULL,
  `working_country` int(11) NOT NULL,
  `working_city` varchar(255) NOT NULL,
  `resident_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `profectional_details` (`id`, `user_id`, `edu_cat`, `edu_item`, `occ_cat`, `employed_in`, `occ_item`, `occ_description`, `income_symbol`, `annual_income`, `working_country`, `working_city`, `resident_status`) VALUES (1, 92, 0, 32, 0, 3, 7, '', '', '3 - 4 Lacks', 10, 'Muttom', 0);
INSERT INTO `profectional_details` (`id`, `user_id`, `edu_cat`, `edu_item`, `occ_cat`, `employed_in`, `occ_item`, `occ_description`, `income_symbol`, `annual_income`, `working_country`, `working_city`, `resident_status`) VALUES (2, 95, 0, 0, 0, 1, 7, '', '', '0 - 1 Lacks', 11, 'QWERTY', 0);
INSERT INTO `profectional_details` (`id`, `user_id`, `edu_cat`, `edu_item`, `occ_cat`, `employed_in`, `occ_item`, `occ_description`, `income_symbol`, `annual_income`, `working_country`, `working_city`, `resident_status`) VALUES (3, 15, 0, 90, 0, 4, 16, '', '', '40 - 50 Lacks', 18, 'SDRTFYGHJK', 0);
INSERT INTO `profectional_details` (`id`, `user_id`, `edu_cat`, `edu_item`, `occ_cat`, `employed_in`, `occ_item`, `occ_description`, `income_symbol`, `annual_income`, `working_country`, `working_city`, `resident_status`) VALUES (4, 96, 0, 52, 0, 2, 8, '', '', '0 - 1 Lacks', 78, 'thiruvananthapuram', 0);
INSERT INTO `profectional_details` (`id`, `user_id`, `edu_cat`, `edu_item`, `occ_cat`, `employed_in`, `occ_item`, `occ_description`, `income_symbol`, `annual_income`, `working_country`, `working_city`, `resident_status`) VALUES (5, 97, 0, 67, 0, 2, 35, '', '', '0 - 1 Lacks', 78, 'trivandrum', 0);


#
# TABLE STRUCTURE FOR: profile_pics
#

DROP TABLE IF EXISTS `profile_pics`;

CREATE TABLE `profile_pics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: profile_type
#

DROP TABLE IF EXISTS `profile_type`;

CREATE TABLE `profile_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `profile_type` (`id`, `name`) VALUES (1, 'Myself');
INSERT INTO `profile_type` (`id`, `name`) VALUES (2, 'Daughter');
INSERT INTO `profile_type` (`id`, `name`) VALUES (3, 'Son');
INSERT INTO `profile_type` (`id`, `name`) VALUES (4, 'Sister');
INSERT INTO `profile_type` (`id`, `name`) VALUES (5, 'Brother');
INSERT INTO `profile_type` (`id`, `name`) VALUES (6, 'Relative');
INSERT INTO `profile_type` (`id`, `name`) VALUES (7, 'Friend');


#
# TABLE STRUCTURE FOR: state
#

DROP TABLE IF EXISTS `state`;

CREATE TABLE `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

INSERT INTO `state` (`id`, `name`) VALUES (1, 'Kerala');
INSERT INTO `state` (`id`, `name`) VALUES (2, 'Karnataka');
INSERT INTO `state` (`id`, `name`) VALUES (3, 'Tamil Nadu');
INSERT INTO `state` (`id`, `name`) VALUES (4, 'Uttar Pradesh');
INSERT INTO `state` (`id`, `name`) VALUES (5, 'Andhra Pradesh');
INSERT INTO `state` (`id`, `name`) VALUES (6, 'Arunachal Pradesh');
INSERT INTO `state` (`id`, `name`) VALUES (7, 'Assam');
INSERT INTO `state` (`id`, `name`) VALUES (8, 'Bihar');
INSERT INTO `state` (`id`, `name`) VALUES (9, 'Chhattisgarh');
INSERT INTO `state` (`id`, `name`) VALUES (10, 'Goa');
INSERT INTO `state` (`id`, `name`) VALUES (11, 'Gujarat');
INSERT INTO `state` (`id`, `name`) VALUES (12, 'Haryana');
INSERT INTO `state` (`id`, `name`) VALUES (13, 'Himachal Pradesh');
INSERT INTO `state` (`id`, `name`) VALUES (14, 'Jammu and Kashmir');
INSERT INTO `state` (`id`, `name`) VALUES (15, 'Jharkhand');
INSERT INTO `state` (`id`, `name`) VALUES (16, 'Madhya Pradesh');
INSERT INTO `state` (`id`, `name`) VALUES (17, 'Maharashtra');
INSERT INTO `state` (`id`, `name`) VALUES (18, 'Manipur');
INSERT INTO `state` (`id`, `name`) VALUES (19, 'Meghalaya');
INSERT INTO `state` (`id`, `name`) VALUES (20, 'Mizoram');
INSERT INTO `state` (`id`, `name`) VALUES (21, 'Nagaland');
INSERT INTO `state` (`id`, `name`) VALUES (22, 'Odisha');
INSERT INTO `state` (`id`, `name`) VALUES (23, 'Punjab');
INSERT INTO `state` (`id`, `name`) VALUES (24, 'Rajasthan');
INSERT INTO `state` (`id`, `name`) VALUES (25, 'Sikkim');
INSERT INTO `state` (`id`, `name`) VALUES (26, 'Telangana');
INSERT INTO `state` (`id`, `name`) VALUES (27, 'Tripura');
INSERT INTO `state` (`id`, `name`) VALUES (28, 'Uttarakhand');
INSERT INTO `state` (`id`, `name`) VALUES (29, 'West Bengal');


#
# TABLE STRUCTURE FOR: subscription
#

DROP TABLE IF EXISTS `subscription`;

CREATE TABLE `subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `transaction_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_declient
#

DROP TABLE IF EXISTS `tbl_declient`;

CREATE TABLE `tbl_declient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_preference
#

DROP TABLE IF EXISTS `tbl_preference`;

CREATE TABLE `tbl_preference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `age_from` int(11) NOT NULL,
  `age_to` int(11) NOT NULL,
  `height_from` int(11) NOT NULL,
  `height_to` int(11) NOT NULL,
  `marital_status` varchar(50) NOT NULL,
  `smoking_habits` varchar(50) NOT NULL,
  `drinking_habits` varchar(50) NOT NULL,
  `education` varchar(200) NOT NULL,
  `occupation` varchar(250) NOT NULL,
  `country` varchar(250) NOT NULL,
  `district` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_preference` (`id`, `user_id`, `age_from`, `age_to`, `height_from`, `height_to`, `marital_status`, `smoking_habits`, `drinking_habits`, `education`, `occupation`, `country`, `district`) VALUES (1, 92, 18, 24, 0, 0, '1', '0', '0', '0', '0', '0', '0');
INSERT INTO `tbl_preference` (`id`, `user_id`, `age_from`, `age_to`, `height_from`, `height_to`, `marital_status`, `smoking_habits`, `drinking_habits`, `education`, `occupation`, `country`, `district`) VALUES (2, 95, 18, 59, 0, 0, '1,2,3,4', '0', '0', '0', '0', '0', '0');
INSERT INTO `tbl_preference` (`id`, `user_id`, `age_from`, `age_to`, `height_from`, `height_to`, `marital_status`, `smoking_habits`, `drinking_habits`, `education`, `occupation`, `country`, `district`) VALUES (3, 15, 18, 0, 0, 0, '1,2,3,4', '0', '0', '0', '0', '0', '0');
INSERT INTO `tbl_preference` (`id`, `user_id`, `age_from`, `age_to`, `height_from`, `height_to`, `marital_status`, `smoking_habits`, `drinking_habits`, `education`, `occupation`, `country`, `district`) VALUES (4, 96, 32, 42, 0, 0, '1,2,3,4', '0', '0', '0', '0', '0', '0');
INSERT INTO `tbl_preference` (`id`, `user_id`, `age_from`, `age_to`, `height_from`, `height_to`, `marital_status`, `smoking_habits`, `drinking_habits`, `education`, `occupation`, `country`, `district`) VALUES (5, 97, 23, 33, 0, 0, '1,2,3,4', '0', '0', '0', '0', '0', '0');


#
# TABLE STRUCTURE FOR: user_categories
#

DROP TABLE IF EXISTS `user_categories`;

CREATE TABLE `user_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: user_contacts
#

DROP TABLE IF EXISTS `user_contacts`;

CREATE TABLE `user_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contacted_user` int(11) NOT NULL,
  `licence_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: user_notification
#

DROP TABLE IF EXISTS `user_notification`;

CREATE TABLE `user_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notify_id` int(11) NOT NULL,
  `notify_from` int(11) NOT NULL,
  `notify_type` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (2, 96, 95, 2, 1, '2022-10-03 05:57:34');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (3, 95, 96, 1, 1, '2022-10-03 05:59:01');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (4, 95, 96, 3, 1, '2022-10-03 06:03:15');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (10, 96, 92, 2, 0, '2022-10-03 06:47:20');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (20, 96, 92, 1, 0, '2022-10-03 06:57:42');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (22, 97, 95, 2, 1, '2022-10-03 07:08:43');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (23, 95, 97, 3, 1, '2022-10-03 07:09:13');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (24, 97, 92, 1, 0, '2022-10-04 04:54:00');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (25, 97, 92, 2, 0, '2022-10-04 04:54:17');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (26, 97, 95, 1, 0, '2022-10-05 05:42:04');
INSERT INTO `user_notification` (`id`, `notify_id`, `notify_from`, `notify_type`, `status`, `created_at`) VALUES (27, 96, 95, 1, 0, '2022-10-06 04:42:37');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kna_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `country_code` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `district` int(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `group_id` int(11) NOT NULL,
  `password_reset_key` varchar(255) NOT NULL,
  `password_reset_key_expiration` datetime DEFAULT NULL,
  `invite_key` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `profile_type` int(11) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  `otp` int(11) NOT NULL,
  `otp_expiration` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (15, 0, 'robinrr', 'roy', 'knanayapartner@gmail.com', 'AL', '5f8437b7b2c7f56dc6c6c3e1b0310ff0', '9633713618', 0, 0, 0, 0, '', 1, 1, '', '0000-00-00 00:00:00', '', '4448d29b8de003153552eedebaf1940e.jpg', 0, '2022-10-08 11:39:49', '2016-11-16 08:08:37', 0, 0, '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (92, 200001, 'robinmon', '', 'robinroyabraham@gmail.com', 'AL', '5f8437b7b2c7f56dc6c6c3e1b0310ff0', '9074656202', 78, 32, 0, 0, 'thodupuzha', 1, 2, '', NULL, 'GrgsIhX27fdhC8u', 'a35a64699ae457266afc56fbd131b57f.jpg', 1, '2022-10-07 03:04:24', '2022-10-01 15:08:44', 0, 0, '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (93, 200002, 'robinmon', '', 'robinroyabraham123@gmail.com', 'AL', '5f8437b7b2c7f56dc6c6c3e1b0310ff0', '9074656203', 78, 32, 0, 0, 'thodupuzha', 2, 2, '', NULL, '2HDBYVdnoCLahDJ', '', 6, NULL, '2022-10-01 15:13:09', 0, 0, '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (94, 200003, 'Jasooly Baliq', '', 'info@smartipz.com', 'AL', '16a6f8ec134a850de8e095f3b459f5ad', '7012712976', 78, 78, 1, 13, 'Varkala', 2, 2, '', NULL, '2Y0gYhNne031rMP', '', 5, NULL, '2022-10-03 04:28:09', 0, 0, '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (95, 200004, 'Jasooly Baliq', '', 'easa.smartipz@gmail.com', 'AL', '16a6f8ec134a850de8e095f3b459f5ad', '7593926000', 78, 78, 1, 13, 'Varkala', 1, 2, '', NULL, '', 'f2924c9d0df3f146c77455cbdb7b989a.png', 6, '2022-10-06 07:04:06', '2022-10-03 04:35:41', 0, 0, '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (96, 200005, 'Jesna', '', 'jesna.smartipz@gmail.com', 'AF', '682ed8e46fc73d22689bc92360b3851b', '7593935000', 78, 78, 1, 13, 'varkala', 1, 2, '', NULL, '', '01b302e017f62143f6116ff38d2abdc4.jpg', 1, '2022-10-03 05:52:39', '2022-10-03 05:49:09', 0, 0, '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (97, 200006, 'akhila', '', 'akhila.smartipz@gmail.com', 'AF', '94fa2442f2160250e56f0504bb1b34d9', '7593923000', 78, 78, 1, 8, 'kollam', 1, 2, '', NULL, '', '', 1, '2022-10-03 07:03:49', '2022-10-03 06:59:11', 0, 0, '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `kna_id`, `first_name`, `last_name`, `email`, `gender`, `password`, `phone`, `country_code`, `country_id`, `state`, `district`, `city`, `is_active`, `group_id`, `password_reset_key`, `password_reset_key_expiration`, `invite_key`, `image`, `profile_type`, `last_login`, `created_at`, `deleted`, `otp`, `otp_expiration`) VALUES (98, 200007, 'Anulekshmi', '', 'anulekshmi.smartipz@gmail.com', 'AF', '5dd87bd2816042f1becfd6dbaab55465', '7593914500', 78, 78, 1, 13, 'Varkala', 2, 2, '', NULL, 'q4cuj0IXGi7NrTb', '', 1, NULL, '2022-10-06 04:47:30', 0, 0, '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: visited_profiles
#

DROP TABLE IF EXISTS `visited_profiles`;

CREATE TABLE `visited_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_id` int(11) NOT NULL,
  `host_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `visited_profiles` (`id`, `visitor_id`, `host_id`) VALUES (2, 96, 95);
INSERT INTO `visited_profiles` (`id`, `visitor_id`, `host_id`) VALUES (17, 92, 96);
INSERT INTO `visited_profiles` (`id`, `visitor_id`, `host_id`) VALUES (19, 92, 97);
INSERT INTO `visited_profiles` (`id`, `visitor_id`, `host_id`) VALUES (20, 95, 97);
INSERT INTO `visited_profiles` (`id`, `visitor_id`, `host_id`) VALUES (21, 95, 96);


